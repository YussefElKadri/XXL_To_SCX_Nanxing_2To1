﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Windows.Forms;
using System.Net.NetworkInformation;
using System.Collections;

namespace XXL_To_SCX_Nanxing_2To1
{
	internal class LeituraEscritaSCX
	{
		readonly ProcessamentoLeitura novoProcessamento = new ProcessamentoLeitura();
		readonly EscritaLeituraToolCfg novaEscritaTool = new EscritaLeituraToolCfg();
		readonly MetodosEscritaSCX novaEscritaSCX = new MetodosEscritaSCX();
		readonly List<string> novaEscritaProfLargCanal = new List<string>();

		private string NomeSCX { get; set; }
		private string NovoNomeSCX { get; set; }
		private string NomeSCX_B { get; set; }
		private string NovoNomeSCX_B { get; set; }
		private int NbFace { get; set; }
		private decimal Larguracanal { get; set; }
		private string Carachineslado { get; set; }
		private int NbFaceB { get; set; }
		private int NbPassadasZ { get; set; }
		private int ValorC { get; set; }
		private string Comchines { get; set; }
		public string LeituraArquivos(string arquivosXXL)
		{
			string pasta = Directory.GetCurrentDirectory();
			string[] listaArquivosXXL = Directory.GetFiles(pasta, "*.*", SearchOption.AllDirectories);

			string pastaSCX = "SCX";

			List<string> listaXXLFULL = new List<string>();
			List<string> listaSCXFULL = new List<string>();
			List<string> listaXXLA = new List<string>();
			List<string> listaXXLB = new List<string>();
			List<string> listaINF = new List<string>();
			List<string> listaXL2PXAR2 = new List<string>();
			List<string> novaEscritaPassadasz = new List<string>();
			novaEscritaTool.CriaPastaArquivoCFGTool();

			for (int i = 0; i < novaEscritaTool.dadoscanallarg.Count; i++) //Dados canal cfg
			{
				novaEscritaProfLargCanal.Add(novaEscritaTool.dadoscanallarg[i]);
			}

			for (int i = 0; i < novaEscritaTool.dadospassadasz.Count; i++) //Dados passada Z cfg
			{
				novaEscritaPassadasz.Add(novaEscritaTool.dadospassadasz[i]);
			}

			for (int h = 0; h < listaArquivosXXL.Length; h++) //Lista todos os xxls
			{
				string nomeXXL = listaArquivosXXL[h];

				if (nomeXXL.EndsWith("1.xxl") || nomeXXL.EndsWith("1.XXL"))
				{
					listaXXLA.Add(listaArquivosXXL[h]);
					listaXXLFULL.Add(listaArquivosXXL[h]);
				}
				if(nomeXXL.EndsWith("2.xxl") || nomeXXL.EndsWith("2.XXL"))
				{
					listaXXLB.Add(listaArquivosXXL[h]);
					listaXXLFULL.Add(listaArquivosXXL[h]);
				}
				else if(nomeXXL.EndsWith(".inf") || nomeXXL.EndsWith(".INF"))
				{
					listaINF.Add(listaArquivosXXL[h]);
				}
			}

			foreach (var xxlA in listaXXLA) //Leitura XXL, escrita SCX A
			{
				Directory.CreateDirectory(Path.GetDirectoryName(xxlA) + @"\" + pastaSCX + @"\");
				listaXL2PXAR2.Clear();

				if (xxlA.EndsWith("1.xxl") || xxlA.EndsWith("1.XXL"))
				{
					string novoNome = Path.GetFileName(xxlA);
					int posicao = novoNome.IndexOf("1.");
					string NovoNomeFinal = novoNome.Substring(0, posicao);
					NomeSCX = NovoNomeFinal + "1.SCX";
					NovoNomeSCX = Path.GetDirectoryName(xxlA) + @"\" + pastaSCX + @"\" + NomeSCX;
				}

				listaSCXFULL.Add(NovoNomeSCX);

				string[] leituratotalxxlA = File.ReadAllLines(xxlA);

				for (int h = 0; h < leituratotalxxlA.Length; h++)
				{
					if (leituratotalxxlA[h].StartsWith("XG0") || leituratotalxxlA[h].StartsWith("XL2P") || leituratotalxxlA[h].StartsWith("XAR2"))
					{
						listaXL2PXAR2.Add(leituratotalxxlA[h]);
					}
				}

				for (int i = 0; i < leituratotalxxlA.Length; i++)
				{
					if (leituratotalxxlA[i].StartsWith("H ")) // Escrita cabecalho
					{
						novoProcessamento.LeituraCabecalho(leituratotalxxlA[i]);
						novaEscritaSCX.EscritaCabecalho(NovoNomeSCX, novoProcessamento.ValorDX, novoProcessamento.ValorDY, novoProcessamento.ValorDZ);
					}
					else if (leituratotalxxlA[i].StartsWith("XBO")) //Escrita furo
					{
						novoProcessamento.LeituraXBO(leituratotalxxlA[i]);
						novaEscritaSCX.EscritaFuro(NovoNomeSCX, novoProcessamento.ValorDZ, novoProcessamento.XFuro, novoProcessamento.YFuro, novoProcessamento.DepthFuroTEMP, novoProcessamento.ZFuro, novoProcessamento.DFuro, novoProcessamento.FFuro, novoProcessamento.TipoFuro);
					}
					else if (leituratotalxxlA[i].StartsWith("LONG")) //Escrita Groove Serra
					{
						if (leituratotalxxlA[i - 1].StartsWith("F=1")) //S
						{
							NbFace = 5;
							novoProcessamento.LeituraLong(leituratotalxxlA[i]);

							for (int j = 0; j < novaEscritaProfLargCanal.Count; j++)
							{
								decimal medidaZLong = novoProcessamento.ZLong;
								string profcanal = novaEscritaProfLargCanal[j].ToString().Split('=')[0];

								if (Convert.ToDecimal(profcanal) == medidaZLong)
								{
									Larguracanal = Convert.ToDecimal(novaEscritaProfLargCanal[j].ToString().Split('=')[1]);
								}
							}

							novaEscritaSCX.EscritaRanhuraSerra(NovoNomeSCX, novoProcessamento.ValorDZ, (novoProcessamento.ValorDX - novoProcessamento.XLong), novoProcessamento.YLong, (novoProcessamento.ValorDX - novoProcessamento.XFLong), novoProcessamento.ZLong, NbFace, Larguracanal);
						}
					}
					else if (leituratotalxxlA[i].StartsWith("FRESATURA_LIN")) //Escrita Groove Fresa
					{
						if (leituratotalxxlA[i - 1].StartsWith("F=1")) //S
						{
							NbFace = 5;
							novoProcessamento.LeituraFresa(leituratotalxxlA[i]);
							decimal ladocompensacao = novoProcessamento.CFresature;

							if (ladocompensacao == 1) //Esq
							{
								Carachineslado = "右";
							}
							else if (ladocompensacao == 2) //Dir
							{
								Carachineslado = "左";
							}
							else
							{
								Carachineslado = "中";
							}

							for (int j = 0; j < novaEscritaProfLargCanal.Count; j++)
							{
								decimal medidaZLong = novoProcessamento.ZFresature;
								string profcanal = novaEscritaProfLargCanal[j].ToString().Split('=')[0];

								if (Convert.ToDecimal(profcanal) == medidaZLong)
								{
									Larguracanal = Convert.ToDecimal(novaEscritaProfLargCanal[j].ToString().Split('=')[1]);
								}

							}

							novaEscritaSCX.EscritaFresa(NovoNomeSCX, novoProcessamento.ValorDZ, (novoProcessamento.ValorDX - novoProcessamento.XFresature), novoProcessamento.YFresature, (novoProcessamento.ValorDX - novoProcessamento.XFFresature), novoProcessamento.YFFresature, novoProcessamento.ZFresature, NbFace, Larguracanal, Carachineslado);
						}
					}
					else if (leituratotalxxlA[i].StartsWith("TASCA_RET")) //Cavidade R
					{
						string campoRaio = leituratotalxxlA[i].ToString().Split(' ')[5];
						decimal valorRaio = Convert.ToDecimal(campoRaio.Split('=')[1]);

						if (leituratotalxxlA[i - 1].StartsWith("F=1")) //S
						{
							novoProcessamento.LeituraTascaRet(leituratotalxxlA[i]);
							NbFace = 5;

							if (novoProcessamento.ZTascaRet > novoProcessamento.ValorDZ / 2) //Loop passada Z
							{
								for (int m = 0; m < novaEscritaPassadasz.Count; m++)
								{
									if (novoProcessamento.ValorDZ == Convert.ToDecimal(novaEscritaPassadasz[m].ToString().Split('=')[0]))
									{
										NbPassadasZ = Convert.ToInt16(novaEscritaPassadasz[m].ToString().Split('=')[1]);
									}
								}

								decimal valorz = Math.Round(novoProcessamento.ZTascaRet / NbPassadasZ, 5);

								for (int n = 0; n < NbPassadasZ; n++)
								{
									int nbposicaovalorz = n + 1;
									decimal novovalorz = Math.Round(valorz * nbposicaovalorz, 2);

									if (valorRaio <= 0)
									{
										novaEscritaSCX.EscritaTasca_RetSup(NovoNomeSCX, novoProcessamento.ValorDX, novoProcessamento.XTascaRet, novoProcessamento.YTascaRet, novoProcessamento.LTascaRet, novoProcessamento.HTascaRet, novovalorz, NbFace);
									}
									else
									{
										novaEscritaSCX.EscritaTasca_RetSupArc(valorRaio, NovoNomeSCX, novoProcessamento.ValorDX, novoProcessamento.XTascaRet, novoProcessamento.YTascaRet, novoProcessamento.LTascaRet, novoProcessamento.HTascaRet, novovalorz , NbFace);
									}
								}
							}
							else
							{
								if (valorRaio <= 0)
								{
									novaEscritaSCX.EscritaTasca_RetSup(NovoNomeSCX, novoProcessamento.ValorDX, novoProcessamento.XTascaRet, novoProcessamento.YTascaRet, novoProcessamento.LTascaRet, novoProcessamento.HTascaRet, novoProcessamento.ZTascaRet, NbFace);
								}
								else
								{
									novaEscritaSCX.EscritaTasca_RetSupArc(valorRaio, NovoNomeSCX, novoProcessamento.ValorDX, novoProcessamento.XTascaRet, novoProcessamento.YTascaRet, novoProcessamento.LTascaRet, novoProcessamento.HTascaRet, novoProcessamento.ZTascaRet, NbFace);
								}
							}
						}
					}
					else if (leituratotalxxlA[i].StartsWith("TASCA_CIR")) //Cavidade c
					{
						if (leituratotalxxlA[i - 1].StartsWith("F=1")) //S
						{
							novoProcessamento.LeituraTascaCir(leituratotalxxlA[i]);
							NbFace = 5;

							if (novoProcessamento.ZTascaCirc > novoProcessamento.ValorDZ / 2) //Loop passada Z
							{
								for (int m = 0; m < novaEscritaPassadasz.Count; m++)
								{
									if (novoProcessamento.ValorDZ == Convert.ToDecimal(novaEscritaPassadasz[m].ToString().Split('=')[0]))
									{
										NbPassadasZ = Convert.ToInt16(novaEscritaPassadasz[m].ToString().Split('=')[1]);
									}
								}

								decimal valorz = Math.Round(novoProcessamento.ZTascaCirc / NbPassadasZ, 5);

								for (int n = 0; n < NbPassadasZ; n++)
								{
									int nbposicaovalorz = n + 1;
									decimal novovalorz = Math.Round(valorz * nbposicaovalorz, 2);

									novaEscritaSCX.EscritaTasca_CircSup(NovoNomeSCX, novoProcessamento.ValorDX, novoProcessamento.XTascaCirc, novoProcessamento.YTascaCirc, novoProcessamento.DTascaCirc, novovalorz, NbFace);
								}
							}
							else
							{
								novaEscritaSCX.EscritaTasca_CircSup(NovoNomeSCX, novoProcessamento.ValorDX, novoProcessamento.XTascaCirc, novoProcessamento.YTascaCirc, novoProcessamento.DTascaCirc, novoProcessamento.ZTascaCirc, NbFace);
							}
						}
					}
					else if (leituratotalxxlA[i].StartsWith("CHANNELX")) //Canal Channel X
					{
						if (leituratotalxxlA[i].Contains("F=1")) //S
						{
							NbFace = 5;
							novoProcessamento.LeituraChannelX(leituratotalxxlA[i]);

							for (int j = 0; j < novaEscritaProfLargCanal.Count; j++)
							{
								decimal medidaZChannel = novoProcessamento.ZChannelX;
								string profcanal = novaEscritaProfLargCanal[j].ToString().Split('=')[0];

								if (Convert.ToDecimal(profcanal) == medidaZChannel)
								{
									Larguracanal = Convert.ToDecimal(novaEscritaProfLargCanal[j].ToString().Split('=')[1]);
								}
							}

							novaEscritaSCX.EscritaChannelX(NovoNomeSCX, novoProcessamento.ValorDZ, (novoProcessamento.ValorDX - novoProcessamento.XChannelX), novoProcessamento.YChannelX, novoProcessamento.ZChannelX, (novoProcessamento.ValorDX - novoProcessamento.sChannelX), NbFace, Larguracanal);
						}
					}
					else if (leituratotalxxlA[i].StartsWith("CHANNELY")) //Canal Channel Y
					{
						if (leituratotalxxlA[i].Contains("F=1")) //S
						{
							NbFace = 5;
							novoProcessamento.LeituraChannelY(leituratotalxxlA[i]);

							for (int j = 0; j < novaEscritaProfLargCanal.Count; j++)
							{
								decimal medidaZChannel = novoProcessamento.ZChannelY;
								string profcanal = novaEscritaProfLargCanal[j].ToString().Split('=')[0];

								if (Convert.ToDecimal(profcanal) == medidaZChannel)
								{
									Larguracanal = Convert.ToDecimal(novaEscritaProfLargCanal[j].ToString().Split('=')[1]);
								}
							}

							novaEscritaSCX.EscritaChannelY(NovoNomeSCX, novoProcessamento.ValorDZ, (novoProcessamento.ValorDX - novoProcessamento.XChannelY), novoProcessamento.sChannelY, novoProcessamento.ZChannelY, (novoProcessamento.YChannelY), NbFace, Larguracanal);
						}
					}
					else if (leituratotalxxlA[i].StartsWith("SCASSOR")) //SCASSOR
					{
						string campoRaio = leituratotalxxlA[i].ToString().Split(' ')[10];
						decimal valorRaio = Convert.ToDecimal(campoRaio.Split('=')[1]);

						if (leituratotalxxlA[i].Contains("F=1")) //S
						{
							novoProcessamento.LeituraScassoR(leituratotalxxlA[i]);
							NbFace = 5;

							for (int k = 0; k < novaEscritaProfLargCanal.Count; k++)
							{
								decimal medidaZLong = novoProcessamento.ZScassor;
								string profcanal = novaEscritaProfLargCanal[k].ToString().Split('=')[0];

								if (Convert.ToDecimal(profcanal) == medidaZLong)
								{
									Larguracanal = Convert.ToDecimal(novaEscritaProfLargCanal[k].ToString().Split('=')[1]);
								}
							}

							if (novoProcessamento.ZScassor > novoProcessamento.ValorDZ / 2) //Loop passada Z
							{
								for (int m = 0; m < novaEscritaPassadasz.Count; m++)
								{
									if (novoProcessamento.ValorDZ == Convert.ToDecimal(novaEscritaPassadasz[m].ToString().Split('=')[0]))
									{
										NbPassadasZ = Convert.ToInt16(novaEscritaPassadasz[m].ToString().Split('=')[1]);
									}
								}

								decimal valorz = Math.Round(novoProcessamento.ZScassor / NbPassadasZ, 5);

								for (int n = 0; n < NbPassadasZ; n++)
								{
									int nbposicaovalorz = n + 1;
									decimal novovalorz = Math.Round(valorz * nbposicaovalorz, 2);

									if (valorRaio <= 0)
									{
										novaEscritaSCX.EscritaScassoRSup(NovoNomeSCX, novoProcessamento.ValorDX, novoProcessamento.XScassor, novoProcessamento.YScassor, novoProcessamento.xScassor, novoProcessamento.yScassor, novovalorz, NbFace, Larguracanal);
									}
									else
									{
										novaEscritaSCX.EscritaScassoRSupArc(valorRaio, NovoNomeSCX, novoProcessamento.ValorDX, novoProcessamento.XScassor, novoProcessamento.YScassor, novoProcessamento.xScassor, novoProcessamento.yScassor, novovalorz, NbFace, Larguracanal);
									}
								}
							}
							else
							{
								if (valorRaio <= 0)
								{
									novaEscritaSCX.EscritaScassoRSup(NovoNomeSCX, novoProcessamento.ValorDX, novoProcessamento.XScassor, novoProcessamento.YScassor, novoProcessamento.xScassor, novoProcessamento.yScassor, novoProcessamento.ZScassor, NbFace, Larguracanal);
								}
								else
								{
									novaEscritaSCX.EscritaScassoRSupArc(valorRaio, NovoNomeSCX, novoProcessamento.ValorDX, novoProcessamento.XScassor, novoProcessamento.YScassor, novoProcessamento.xScassor, novoProcessamento.yScassor, novoProcessamento.ZScassor, NbFace, Larguracanal);
								}
							}
						}
					}
					else if (leituratotalxxlA[i].StartsWith("SCASSOC")) //SCASSOC
					{
						if (leituratotalxxlA[i].Contains("F=1")) //S
						{
							novoProcessamento.LeituraScassoC(leituratotalxxlA[i]);
							NbFace = 5;

							if (novoProcessamento.ZScassoc > novoProcessamento.ValorDZ / 2) //Loop passada Z
							{
								for (int m = 0; m < novaEscritaPassadasz.Count; m++)
								{
									if (novoProcessamento.ValorDZ == Convert.ToDecimal(novaEscritaPassadasz[m].ToString().Split('=')[0]))
									{
										NbPassadasZ = Convert.ToInt16(novaEscritaPassadasz[m].ToString().Split('=')[1]);
									}
								}

								decimal valorz = Math.Round(novoProcessamento.ZScassoc / NbPassadasZ, 5);

								for (int n = 0; n < NbPassadasZ; n++)
								{
									int nbposicaovalorz = n + 1;
									decimal novovalorz = Math.Round(valorz * nbposicaovalorz, 2);

									novaEscritaSCX.EscritaScassocSup(NovoNomeSCX, novoProcessamento.ValorDX, novoProcessamento.XScassoc, novoProcessamento.YScassoc, novoProcessamento.xScassoc, novovalorz, NbFace);
								}
							}
							else
							{
								novaEscritaSCX.EscritaScassocSup(NovoNomeSCX, novoProcessamento.ValorDX, novoProcessamento.XScassoc, novoProcessamento.YScassoc, novoProcessamento.xScassoc, novoProcessamento.ZScassoc, NbFace);
							}
						}
					}
					else if (leituratotalxxlA[i].StartsWith("XG0"))
					{
						string linha = leituratotalxxlA[i];
						string linhaanterior = leituratotalxxlA[i - 1];
						Compensacao(linha, linhaanterior);
						CiclosFreeMilling(listaXL2PXAR2.ToArray(), 5, Comchines);
						listaXL2PXAR2.Clear();
					}
				}
			}

			foreach (var xxlB in listaXXLB) //Leitura XXL, escrita SCX B
			{
				decimal ValTempDZ = 0;

				if (xxlB.EndsWith("2.xxl") || xxlB.EndsWith("2.XXL"))
				{
					string novoNome = Path.GetFileName(xxlB);
					int posicao = novoNome.IndexOf("2.");
					string NovoNomeFinal = novoNome.Substring(0, posicao);
					NomeSCX_B = NovoNomeFinal + "1.SCX";
					NovoNomeSCX_B = Path.GetDirectoryName(xxlB) + @"\" + pastaSCX + @"\" + NomeSCX_B;
				}

				string[] leituratotalxxlB = File.ReadAllLines(xxlB);

				for (int i = 0; i < leituratotalxxlB.Length; i++)
				{
					if (leituratotalxxlB[i].StartsWith("H ")) // Escrita cabecalho
					{
						novoProcessamento.LeituraCabecalho(leituratotalxxlB[i]);
						ValTempDZ = novoProcessamento.ValorDZ;
					}
					else if (leituratotalxxlB[i].StartsWith("XBO")) //Escrita furo
					{
						NbFaceB = 6;
						novoProcessamento.LeituraXBO(leituratotalxxlB[i]);
						novaEscritaSCX.EscritaFuro(NovoNomeSCX_B, ValTempDZ, (novoProcessamento.ValorDX - novoProcessamento.XFuro), novoProcessamento.YFuro, novoProcessamento.DepthFuroTEMP, novoProcessamento.ZFuro, novoProcessamento.DFuro, NbFaceB, novoProcessamento.TipoFuro);
					}
					else if (leituratotalxxlB[i].StartsWith("LONG")) //Escrita Groove Serra
					{
						NbFaceB = 6;
						novoProcessamento.LeituraLong(leituratotalxxlB[i]);

						for (int j = 0; j < novaEscritaProfLargCanal.Count; j++)
						{
							decimal medidaZLong = novoProcessamento.ZLong;
							string profcanal = novaEscritaProfLargCanal[j].ToString().Split('=')[0];

							if (Convert.ToDecimal(profcanal) == medidaZLong)
							{
								Larguracanal = Convert.ToDecimal(novaEscritaProfLargCanal[j].ToString().Split('=')[1]);
							}
						}

						novaEscritaSCX.EscritaRanhuraSerra(NovoNomeSCX_B, novoProcessamento.ValorDZ, novoProcessamento.XLong, novoProcessamento.YLong, novoProcessamento.XFLong, novoProcessamento.ZLong, NbFaceB, Larguracanal);
					}
					else if (leituratotalxxlB[i].StartsWith("FRESATURA_LIN")) //Escrita Groove Fresa
					{
						NbFaceB = 6;
						novoProcessamento.LeituraFresa(leituratotalxxlB[i]);
						decimal ladocompensacao = novoProcessamento.CFresature;

						if (ladocompensacao == 1) //Esq
						{
							Carachineslado = "右";
						}
						else if (ladocompensacao == 2) //Dir
						{
							Carachineslado = "左";
						}
						else
						{
							Carachineslado = "中"; //Cent
						}

						for (int j = 0; j < novaEscritaProfLargCanal.Count; j++)
						{
							decimal medidaZLong = novoProcessamento.ZFresature;
							string profcanal = novaEscritaProfLargCanal[j].ToString().Split('=')[0];

							if (Convert.ToDecimal(profcanal) == medidaZLong)
							{
								Larguracanal = Convert.ToDecimal(novaEscritaProfLargCanal[j].ToString().Split('=')[1]);
							}
						}

						novaEscritaSCX.EscritaFresa(NovoNomeSCX_B, novoProcessamento.ValorDZ, (novoProcessamento.ValorDX - novoProcessamento.XFresature), novoProcessamento.YFresature, (novoProcessamento.ValorDX - novoProcessamento.XFFresature), novoProcessamento.YFFresature, novoProcessamento.ZFresature, NbFaceB, Larguracanal, Carachineslado);

					}
					else if (leituratotalxxlB[i].StartsWith("TASCA_RET")) //Cavidade R
					{
						string campoRaio = leituratotalxxlB[i].ToString().Split(' ')[5];
						decimal valorRaio = Convert.ToDecimal(campoRaio.Split('=')[1]);
						novoProcessamento.LeituraTascaRet(leituratotalxxlB[i]);

						if (Convert.ToDecimal(novoProcessamento.ZTascaRet) >= Convert.ToDecimal(novoProcessamento.ValorDZ))
						{
							NbFaceB = 5;
						}
						else
						{
							NbFaceB = 6;
						}

						if (novoProcessamento.ZTascaRet > novoProcessamento.ValorDZ / 2) //Loop passada Z
						{
							for (int m = 0; m < novaEscritaPassadasz.Count; m++)
							{
								if (novoProcessamento.ValorDZ == Convert.ToDecimal(novaEscritaPassadasz[m].ToString().Split('=')[0]))
								{
									NbPassadasZ = Convert.ToInt16(novaEscritaPassadasz[m].ToString().Split('=')[1]);
								}
							}

							decimal valorz = Math.Round(novoProcessamento.ZTascaRet / NbPassadasZ, 5);

							for (int n = 0; n < NbPassadasZ; n++)
							{
								int nbposicaovalorz = n + 1;
								decimal novovalorz = Math.Round(valorz * nbposicaovalorz, 2);

								if (valorRaio <= 0)
								{
									novaEscritaSCX.EscritaTasca_RetInf(NovoNomeSCX_B, novoProcessamento.XTascaRet, novoProcessamento.YTascaRet, novoProcessamento.LTascaRet, novoProcessamento.HTascaRet, novovalorz, NbFaceB);
								}
								else
								{
									novaEscritaSCX.EscritaTasca_RetInfArc(valorRaio, NovoNomeSCX_B, novoProcessamento.XTascaRet, novoProcessamento.YTascaRet, novoProcessamento.LTascaRet, novoProcessamento.HTascaRet, novovalorz, NbFaceB);
								}
							}
						}
						else
						{
							if (valorRaio <= 0)
							{
								novaEscritaSCX.EscritaTasca_RetInf(NovoNomeSCX_B, novoProcessamento.XTascaRet, novoProcessamento.YTascaRet, novoProcessamento.LTascaRet, novoProcessamento.HTascaRet, novoProcessamento.ZTascaRet, NbFaceB);
							}
							else
							{
								novaEscritaSCX.EscritaTasca_RetInfArc(valorRaio, NovoNomeSCX_B, novoProcessamento.XTascaRet, novoProcessamento.YTascaRet, novoProcessamento.LTascaRet, novoProcessamento.HTascaRet, novoProcessamento.ZTascaRet, NbFaceB);
							}
						}
					}
					else if (leituratotalxxlB[i].StartsWith("TASCA_CIR")) //Cavidade c
					{
						novoProcessamento.LeituraTascaCir(leituratotalxxlB[i]);

						if (novoProcessamento.ZTascaCirc > novoProcessamento.ValorDZ / 2) //Loop passada Z
						{
							for (int m = 0; m < novaEscritaPassadasz.Count; m++)
							{
								if (novoProcessamento.ValorDZ == Convert.ToDecimal(novaEscritaPassadasz[m].ToString().Split('=')[0]))
								{
									NbPassadasZ = Convert.ToInt16(novaEscritaPassadasz[m].ToString().Split('=')[1]);
								}
							}

							decimal valorz = Math.Round(novoProcessamento.ZTascaCirc / NbPassadasZ, 5);

							for (int n = 0; n < NbPassadasZ; n++)
							{
								int nbposicaovalorz = n + 1;
								decimal novovalorz = Math.Round(valorz * nbposicaovalorz, 2);
								novaEscritaSCX.EscritaTasca_CircInf(NovoNomeSCX_B, novoProcessamento.ValorDX, novoProcessamento.ValorDY, novoProcessamento.XTascaCirc, novoProcessamento.YTascaCirc, novoProcessamento.DTascaCirc, novovalorz, NbFaceB);
							}
						}
						else
						{
							novaEscritaSCX.EscritaTasca_CircInf(NovoNomeSCX_B, novoProcessamento.ValorDX, novoProcessamento.ValorDY, novoProcessamento.XTascaCirc, novoProcessamento.YTascaCirc, novoProcessamento.DTascaCirc, novoProcessamento.ZTascaCirc, NbFaceB);
						}
					}
					else if (leituratotalxxlB[i].StartsWith("CHANNELX")) //Canal Channel X
					{
						if (leituratotalxxlB[i].Contains("F=1")) //S
						{
							NbFace = 6;
							novoProcessamento.LeituraChannelX(leituratotalxxlB[i]);

							for (int j = 0; j < novaEscritaProfLargCanal.Count; j++)
							{
								decimal medidaZChannel = novoProcessamento.ZChannelX;
								string profcanal = novaEscritaProfLargCanal[j].ToString().Split('=')[0];

								if (Convert.ToDecimal(profcanal) == medidaZChannel)
								{
									Larguracanal = Convert.ToDecimal(novaEscritaProfLargCanal[j].ToString().Split('=')[1]);
								}
							}

							novaEscritaSCX.EscritaChannelX(NovoNomeSCX_B, novoProcessamento.ValorDZ, novoProcessamento.XChannelX, novoProcessamento.YChannelX, novoProcessamento.ZChannelX, novoProcessamento.sChannelX, NbFace, Larguracanal);
						}
					}
					else if (leituratotalxxlB[i].StartsWith("CHANNELY")) //Canal Channel Y
					{
						if (leituratotalxxlB[i].Contains("F=1")) //S
						{
							NbFace = 6;
							novoProcessamento.LeituraChannelY(leituratotalxxlB[i]);

							for (int j = 0; j < novaEscritaProfLargCanal.Count; j++)
							{
								decimal medidaZChannel = novoProcessamento.ZChannelY;
								string profcanal = novaEscritaProfLargCanal[j].ToString().Split('=')[0];

								if (Convert.ToDecimal(profcanal) == medidaZChannel)
								{
									Larguracanal = Convert.ToDecimal(novaEscritaProfLargCanal[j].ToString().Split('=')[1]);
								}
							}

							novaEscritaSCX.EscritaChannelY(NovoNomeSCX_B, novoProcessamento.ValorDZ, novoProcessamento.XChannelY, novoProcessamento.YChannelY, novoProcessamento.ZChannelY, novoProcessamento.sChannelY, NbFace, Larguracanal);
						}
					}
					else if (leituratotalxxlB[i].StartsWith("SCASSOR")) //SCASSOR
					{
						string campoRaio = leituratotalxxlB[i].ToString().Split(' ')[10];
						decimal valorRaio = Convert.ToDecimal(campoRaio.Split('=')[1]);
						novoProcessamento.LeituraScassoR(leituratotalxxlB[i]);

						if (Convert.ToDecimal(novoProcessamento.ZScassor) >= Convert.ToDecimal(novoProcessamento.ValorDZ))
						{
							NbFaceB = 5;
						}
						else
						{
							NbFaceB = 6;
						}

						for (int k = 0; k < novaEscritaProfLargCanal.Count; k++)
						{
							decimal medidaZLong = novoProcessamento.ZScassor;
							string profcanal = novaEscritaProfLargCanal[k].ToString().Split('=')[0];

							if (Convert.ToDecimal(profcanal) == medidaZLong)
							{
								Larguracanal = Convert.ToDecimal(novaEscritaProfLargCanal[k].ToString().Split('=')[1]);
							}
						}

						if (novoProcessamento.ZScassor > novoProcessamento.ValorDZ / 2) //Loop passada Z
						{
							for (int m = 0; m < novaEscritaPassadasz.Count; m++)
							{
								if (novoProcessamento.ValorDZ == Convert.ToDecimal(novaEscritaPassadasz[m].ToString().Split('=')[0]))
								{
									NbPassadasZ = Convert.ToInt16(novaEscritaPassadasz[m].ToString().Split('=')[1]);
								}
							}

							decimal valorz = Math.Round(novoProcessamento.ZScassor / NbPassadasZ, 5);

							for (int n = 0; n < NbPassadasZ; n++)
							{
								int nbposicaovalorz = n + 1;
								decimal novovalorz = Math.Round(valorz * nbposicaovalorz, 2);

								if (valorRaio <= 0)
								{
									novaEscritaSCX.EscritaScassoRInf(NovoNomeSCX_B, novoProcessamento.XScassor, novoProcessamento.YScassor, novoProcessamento.xScassor, novoProcessamento.yScassor, novovalorz, NbFaceB, Larguracanal);
								}
								else
								{
									novaEscritaSCX.EscritaScassoRInfArc(valorRaio, NovoNomeSCX_B, novoProcessamento.XScassor, novoProcessamento.YScassor, novoProcessamento.xScassor, novoProcessamento.yScassor, novovalorz, NbFaceB, Larguracanal);
								}
							}
						}
						else
						{
							if (valorRaio <= 0)
							{
								novaEscritaSCX.EscritaScassoRInf(NovoNomeSCX_B, novoProcessamento.XScassor, novoProcessamento.YScassor, novoProcessamento.xScassor, novoProcessamento.yScassor, novoProcessamento.ZScassor, NbFaceB,Larguracanal);
							}
							else
							{
								novaEscritaSCX.EscritaScassoRInfArc(valorRaio, NovoNomeSCX_B, novoProcessamento.XScassor, novoProcessamento.YScassor, novoProcessamento.xScassor, novoProcessamento.yScassor, novoProcessamento.ZScassor, NbFaceB,Larguracanal);
							}
						}
					}
					else if (leituratotalxxlB[i].StartsWith("SCASSOC")) //SCASSOC
					{
						if (novoProcessamento.ZScassoc > novoProcessamento.ValorDZ / 2) //Loop passada Z
						{
							for (int m = 0; m < novaEscritaPassadasz.Count; m++)
							{
								if (novoProcessamento.ValorDZ == Convert.ToDecimal(novaEscritaPassadasz[m].ToString().Split('=')[0]))
								{
									NbPassadasZ = Convert.ToInt16(novaEscritaPassadasz[m].ToString().Split('=')[1]);
								}
							}

							decimal valorz = Math.Round(novoProcessamento.ZScassoc / NbPassadasZ, 5);

							for (int n = 0; n < NbPassadasZ; n++)
							{
								int nbposicaovalorz = n + 1;
								decimal novovalorz = Math.Round(valorz * nbposicaovalorz, 2);
								novaEscritaSCX.EscritaScassocInf(NovoNomeSCX_B, novoProcessamento.ValorDX, novoProcessamento.XScassoc, novoProcessamento.YScassoc, novoProcessamento.xScassoc, novovalorz, NbFaceB);
							}
						}
						else
						{
							novaEscritaSCX.EscritaScassocInf(NovoNomeSCX_B, novoProcessamento.ValorDX, novoProcessamento.XScassoc, novoProcessamento.YScassoc, novoProcessamento.xScassoc, novoProcessamento.ZScassoc, NbFaceB);
						}
					}
				}
			}

			foreach (var xxlFULL in listaSCXFULL)
			{
				novaEscritaSCX.EscritaRodape(xxlFULL); //Escrita rodape
			}

			//foreach (var item in listaXXLFULL)
			//{
			//	File.Delete(item); //Apaga XXl antigo
			//}

			foreach (var item in listaINF)
			{
				File.Delete(item); //Apaga inf
			}

			return arquivosXXL;
		}

		public void CiclosFreeMilling(string[] array, int nbFaceUsi, string compensacao)
		{
			// Lista para armazenar todos os ciclos
			List<List<string>> listadeciclos = new List<List<string>>();

			// Lista temporária para armazenar o ciclo atua
			List<string> cicloatual = null;

			// Iteracao array
			foreach (string item in array)
			{
				if (item.StartsWith("XG0"))
				{
					// Quando XGO encontrado, começa um novo ciclo
					if (cicloatual != null)
					{
						// Adicionar o ciclo anterior à lista de ciclos
						listadeciclos.Add(cicloatual);
					}

					// Começa um novo ciclo
					cicloatual = new List<string>();
				}

				// Adicionar o item atual ao ciclo atual, se o ciclo atual for diferente de nulo
				cicloatual?.Add(item);
			}

			// Adicionar o último ciclo à lista de ciclos se existir
			if (cicloatual != null)
			{
				listadeciclos.Add(cicloatual);
			}

			// Escreve os ciclos
			for (int i = 0; i < listadeciclos.Count; i++)
			{
				string[] linhasplit = listadeciclos[i].ToArray();
				int dimfimarray = linhasplit.Length - 1;

				for (int j = 0; j < linhasplit.Length; j++)
				{
					string linhadados = linhasplit[j];

					novoProcessamento.LeituraXG0(linhadados);
					novoProcessamento.LeituraXL2P(linhadados);
					novoProcessamento.LeituraXAR2(linhadados);

					for (int k = 0; k < novaEscritaProfLargCanal.Count; k++)
					{
						decimal medidaZLong = novoProcessamento.Zxg0;
						string profcanal = novaEscritaProfLargCanal[k].ToString().Split('=')[0];

						if (Convert.ToDecimal(profcanal) == medidaZLong)
						{
							Larguracanal = Convert.ToDecimal(novaEscritaProfLargCanal[k].ToString().Split('=')[1]);
						}
					}

					novaEscritaSCX.EscritaXL2PX2AR(NovoNomeSCX, novoProcessamento.ValorDX, j, dimfimarray, nbFaceUsi, novoProcessamento.Xxg0, novoProcessamento.Yxg0, novoProcessamento.Zxg0, Larguracanal, novoProcessamento.Xxl2p, novoProcessamento.Yxl2p, 0, compensacao);
				}
			}
		}

		public void Compensacao(string linha, string linhaanterior)
		{
			if (linha.Contains("C="))
			{
				string[] arrayvalorC = linha.ToString().Split(' ');

				for (int ia = 0; ia < arrayvalorC.Length; ia++)
				{
					if (arrayvalorC[ia].StartsWith("C="))
					{
						ValorC = Convert.ToInt32(arrayvalorC[ia].ToString().Replace("C=", ""));

						switch (ValorC)
						{
							case 0:
								Comchines = "中"; //Centro
								break;
							case 1:
								Comchines = "右"; //Direito
								break;
							case 2:
								Comchines = "左"; //Esquerdo
								break;
							default:
								Comchines = "";
								break;
						}
					}
				}
			}
			else if ((linhaanterior.StartsWith("XGIN") && linhaanterior.Contains("C=")))
			{
				string[] arrayvalorC = linhaanterior.ToString().Split(' ');

				for (int ia = 0; ia < arrayvalorC.Length; ia++)
				{
					if (arrayvalorC[ia].StartsWith("C="))
					{
						ValorC = Convert.ToInt32(arrayvalorC[ia].ToString().Replace("C=", ""));

						switch (ValorC)
						{
							case 0:
								Comchines = "中"; //Centro
								break;
							case 1:
								Comchines = "右"; //Direito
								break;
							case 2:
								Comchines = "左"; //Esquerdo
								break;
							default:
								Comchines = "";
								break;
						}
					}
				}
			}
		}
	}
}


#region Temp

#endregion