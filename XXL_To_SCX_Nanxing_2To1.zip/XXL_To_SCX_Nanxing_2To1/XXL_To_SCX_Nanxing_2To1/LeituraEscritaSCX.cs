﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Windows.Forms;

namespace XXL_To_SCX_Nanxing_2To1
{
	internal class LeituraEscritaSCX
	{
		private string NomeSCX { get; set; }
		private string NovoNomeSCX { get; set; }
		private string NomeSCX_B { get; set; }
		private string NovoNomeSCX_B { get; set; }
		private int NbFace { get; set; }
		private decimal Larguracanal { get; set; }
		private string Carachineslado { get; set; }
		public string LeituraArquivos(string arquivosXXL)
		{
			string pasta = Directory.GetCurrentDirectory();
			string[] listaArquivosXXL = Directory.GetFiles(pasta, "*.*", SearchOption.AllDirectories);

			string pastaSCX = "SCX";

			List<string> listaXXLFULL = new List<string>();
			List<string> listaSCXFULL = new List<string>();
			List<string> listaXXLA = new List<string>();
			List<string> listaXXLB = new List<string>();
			List<string> listaINF = new List<string>();
			List<string> novaEscritaProfLargCanal = new List<string>();
			ProcessamentoLeitura novoProcessamento = new ProcessamentoLeitura();
			EscritaLeituraToolCfg novaEscritaTool = new EscritaLeituraToolCfg();
			EscritaSCX novaEscritaSCX = new EscritaSCX();
			novaEscritaTool.CriaPastaArquivoCFGTool();

			for (int i = 0; i < novaEscritaTool.dadoscanal.Count; i++)
			{
				novaEscritaProfLargCanal.Add(novaEscritaTool.dadoscanal[i]);
			}

			for (int h = 0; h < listaArquivosXXL.Length; h++) //Lista todos os xxls
			{
				string nomeXXL = listaArquivosXXL[h];

				if (nomeXXL.EndsWith("1.xxl") || nomeXXL.EndsWith("1.XXL"))
				{
					listaXXLA.Add(listaArquivosXXL[h]);
					listaXXLFULL.Add(listaArquivosXXL[h]);
				}
				if(nomeXXL.EndsWith("2.xxl") || nomeXXL.EndsWith("2.XXL"))
				{
					listaXXLB.Add(listaArquivosXXL[h]);
					listaXXLFULL.Add(listaArquivosXXL[h]);
				}
				else if(nomeXXL.EndsWith(".inf") || nomeXXL.EndsWith(".INF"))
				{
					listaINF.Add(listaArquivosXXL[h]);
				}
			}

			foreach (var xxlA in listaXXLA) //Leitura XXL, escrita SCX A
			{
				Directory.CreateDirectory(Path.GetDirectoryName(xxlA) + @"\" + pastaSCX + @"\");

				if (xxlA.EndsWith("1.xxl") || xxlA.EndsWith("1.XXL"))
				{
					string novoNome = Path.GetFileName(xxlA);
					int posicao = novoNome.IndexOf("1.");
					string NovoNomeFinal = novoNome.Substring(0, posicao);
					NomeSCX = NovoNomeFinal + "1.SCX";
					NovoNomeSCX = Path.GetDirectoryName(xxlA) + @"\" + pastaSCX + @"\" + NomeSCX;
				}

				listaSCXFULL.Add(NovoNomeSCX);

				string[] leituratotalxxlA = File.ReadAllLines(xxlA);

				for (int i = 0; i < leituratotalxxlA.Length; i++)
				{
					if (leituratotalxxlA[i].StartsWith("H ")) // Escrita cabecalho
					{
						novoProcessamento.LeituraCabecalho(leituratotalxxlA[i]);
						novaEscritaSCX.EscritaCabecalho(NovoNomeSCX, novoProcessamento.ValorDX, novoProcessamento.ValorDY, novoProcessamento.ValorDZ);
					}
					else if (leituratotalxxlA[i].StartsWith("XBO")) //Escrita furo
					{
						novoProcessamento.LeituraXBO(leituratotalxxlA[i]);
						novaEscritaSCX.EscritaFuro(NovoNomeSCX, novoProcessamento.ValorDZ, novoProcessamento.XFuro, novoProcessamento.YFuro, novoProcessamento.DepthFuroTEMP, novoProcessamento.ZFuro, novoProcessamento.DFuro, novoProcessamento.FFuro, novoProcessamento.TipoFuro);
					}
					else if (leituratotalxxlA[i].StartsWith("LONG")) //Escrita Groove Serra
					{
						if (leituratotalxxlA[i - 1].StartsWith("F=1")) //S
						{
							NbFace = 5;
							novoProcessamento.LeituraLong(leituratotalxxlA[i]);

							for (int j = 0; j < novaEscritaProfLargCanal.Count; j++)
							{
								decimal medidaZLong = novoProcessamento.ZLong;
								string profcanal = novaEscritaProfLargCanal[j].ToString().Split('=')[0];

								if (Convert.ToDecimal(profcanal) == medidaZLong)
								{
									Larguracanal = Convert.ToDecimal(novaEscritaProfLargCanal[j].ToString().Split('=')[1]);
								}
							}

							novaEscritaSCX.EscritaRanhuraSerra(NovoNomeSCX, novoProcessamento.ValorDZ, (novoProcessamento.ValorDX - novoProcessamento.XLong), novoProcessamento.YLong, (novoProcessamento.ValorDX - novoProcessamento.XFLong), novoProcessamento.ZLong, NbFace, Larguracanal);
						}
						#region Groove serra face 6
						//else if (leituratotalxxlA[i - 1].StartsWith("F=6")) //I
						//{
						//	NbFace = 6;
						//	novoProcessamento.LeituraLong(leituratotalxxlA[i]);

						//	for (int j = 0; j < novaEscritaProfLargCanal.Count; j++)
						//	{
						//		decimal medidaZLong = novoProcessamento.ZLong;
						//		string profcanal = novaEscritaProfLargCanal[j].ToString().Split('=')[0];

						//		if (Convert.ToDecimal(profcanal) == medidaZLong)
						//		{
						//			Larguracanal = Convert.ToDecimal(novaEscritaProfLargCanal[j].ToString().Split('=')[1]);
						//		}
						//	}

						//	novaEscritaSCX.EscritaRanhuraSerra(NovoNomeSCX, novoProcessamento.ValorDZ, novoProcessamento.XLong, (novoProcessamento.ValorDY - novoProcessamento.YLong), novoProcessamento.XFLong, novoProcessamento.ZLong, NbFace, Larguracanal);
						//}
						#endregion
					}
					else if (leituratotalxxlA[i].StartsWith("FRESATURA_LIN")) //Escrita Groove Fresa
					{
						if (leituratotalxxlA[i - 1].StartsWith("F=1")) //S
						{
							NbFace = 5;
							novoProcessamento.LeituraFresa(leituratotalxxlA[i]);
							decimal ladocompensacao = novoProcessamento.CFresature;

							if (ladocompensacao == 1) //Esq
							{
								Carachineslado = "右";
							}
							else if (ladocompensacao == 2) //Dir
							{
								Carachineslado = "左";
							}
							else
							{
								Carachineslado = "中";
							}

							for (int j = 0; j < novaEscritaProfLargCanal.Count; j++)
							{
								decimal medidaZLong = novoProcessamento.ZFresature;
								string profcanal = novaEscritaProfLargCanal[j].ToString().Split('=')[0];

								if (Convert.ToDecimal(profcanal) == medidaZLong)
								{
									Larguracanal = Convert.ToDecimal(novaEscritaProfLargCanal[j].ToString().Split('=')[1]);
								}

							}

							novaEscritaSCX.EscritaFresa(NovoNomeSCX, novoProcessamento.ValorDZ, (novoProcessamento.ValorDX - novoProcessamento.XFresature), novoProcessamento.YFresature, (novoProcessamento.ValorDX - novoProcessamento.XFFresature), novoProcessamento.YFFresature, novoProcessamento.ZFresature, NbFace, Larguracanal, Carachineslado);
						}
						#region Groove fresa face 6
						//else if (leituratotalxxlA[i - 1].StartsWith("F=6")) //I
						//{
						//	NbFace = 6;
						//	novoProcessamento.LeituraFresa(leituratotalxxlA[i]);

						//	for (int j = 0; j < novaEscritaProfLargCanal.Count; j++)
						//	{
						//		decimal medidaZLong = novoProcessamento.ZFresature;
						//		string profcanal = novaEscritaProfLargCanal[j].ToString().Split('=')[0];

						//		if (Convert.ToDecimal(profcanal) == medidaZLong)
						//		{
						//			Larguracanal = Convert.ToDecimal(novaEscritaProfLargCanal[j].ToString().Split('=')[1]);
						//		}
						//	}

						//	novaEscritaSCX.EscritaFresa(NovoNomeSCX, novoProcessamento.ValorDZ, novoProcessamento.XFresature, (novoProcessamento.ValorDY - novoProcessamento.YFresature), novoProcessamento.XFFresature, (novoProcessamento.ValorDY - novoProcessamento.YFFresature), novoProcessamento.ZFresature, NbFace, Larguracanal);
						//}
						#endregion
					}
					else if (leituratotalxxlA[i].StartsWith("TASCA_RET")) //Cavidade R
					{
						if (leituratotalxxlA[i - 1].StartsWith("F=1")) //S
						{
							NbFace = 5;
							novoProcessamento.LeituraTascaRet(leituratotalxxlA[i]);
							novaEscritaSCX.EscritaTasca_RetSup(NovoNomeSCX, novoProcessamento.ValorDX, novoProcessamento.XTascaRet, novoProcessamento.YTascaRet, novoProcessamento.LTascaRet, novoProcessamento.HTascaRet, novoProcessamento.ZTascaRet, NbFace);
						}
						#region cavidade ret face 6
						//else if (leituratotalxxlA[i - 1].StartsWith("F=6")) //I
						//{
						//	NbFace = 6;
						//	novoProcessamento.LeituraTascaRet(leituratotalxxlA[i]);
						//	novaEscritaSCX.EscritaTasca_RetInf(NovoNomeSCX, novoProcessamento.ValorDX, novoProcessamento.ValorDY, novoProcessamento.XTascaRet, novoProcessamento.YTascaRet, novoProcessamento.LTascaRet, novoProcessamento.HTascaRet, novoProcessamento.ZTascaRet, NbFace);
						//}
						#endregion
					}
					else if (leituratotalxxlA[i].StartsWith("TASCA_CIR")) //Cavidade c
					{
						if (leituratotalxxlA[i - 1].StartsWith("F=1")) //S
						{
							NbFace = 5;
							novoProcessamento.LeituraTascaCir(leituratotalxxlA[i]);
							novaEscritaSCX.EscritaTasca_CircSup(NovoNomeSCX, novoProcessamento.ValorDX, novoProcessamento.XTascaCirc, novoProcessamento.YTascaCirc, novoProcessamento.DTascaCirc, novoProcessamento.ZTascaCirc, NbFace);
						}
						#region cavidade circ face 6
						//else if (leituratotalxxlA[i - 1].StartsWith("F=6")) //I
						//{
						//	NbFace = 6;
						//	novoProcessamento.LeituraTascaCir(leituratotalxxlA[i]);
						//	novaEscritaSCX.EscritaTasca_CircInf(NovoNomeSCX, novoProcessamento.ValorDX, novoProcessamento.ValorDY, novoProcessamento.XTascaCirc, novoProcessamento.YTascaCirc, novoProcessamento.DTascaCirc, novoProcessamento.ZTascaCirc, NbFace);
						//}
						#endregion
					}
				}				
			}

			foreach (var xxlB in listaXXLB) //Leitura XXL, escrita SCX B
			{
				const int NbFaceB = 6;				
				decimal ValTempDZ = 0;

				if (xxlB.EndsWith("2.xxl") || xxlB.EndsWith("2.XXL"))
				{
					string novoNome = Path.GetFileName(xxlB);
					int posicao = novoNome.IndexOf("2.");
					string NovoNomeFinal = novoNome.Substring(0, posicao);
					NomeSCX_B = NovoNomeFinal + "1.SCX";
					NovoNomeSCX_B = Path.GetDirectoryName(xxlB) + @"\" + pastaSCX + @"\" + NomeSCX_B;
				}

				string[] leituratotalxxlB = File.ReadAllLines(xxlB);

				for (int i = 0; i < leituratotalxxlB.Length; i++)
				{
					if (leituratotalxxlB[i].StartsWith("H ")) // Escrita cabecalho
					{
						novoProcessamento.LeituraCabecalho(leituratotalxxlB[i]);
						ValTempDZ = novoProcessamento.ValorDZ;
					}
					else if (leituratotalxxlB[i].StartsWith("XBO")) //Escrita furo
					{
						novoProcessamento.LeituraXBO(leituratotalxxlB[i]);
						novaEscritaSCX.EscritaFuro(NovoNomeSCX_B, ValTempDZ, (novoProcessamento.ValorDX - novoProcessamento.XFuro) , novoProcessamento.YFuro, novoProcessamento.DepthFuroTEMP, novoProcessamento.ZFuro, novoProcessamento.DFuro, NbFaceB, novoProcessamento.TipoFuro);
					}
					else if (leituratotalxxlB[i].StartsWith("LONG")) //Escrita Groove Serra
					{
						novoProcessamento.LeituraLong(leituratotalxxlB[i]);

						for (int j = 0; j < novaEscritaProfLargCanal.Count; j++)
						{
							decimal medidaZLong = novoProcessamento.ZLong;
							string profcanal = novaEscritaProfLargCanal[j].ToString().Split('=')[0];

							if (Convert.ToDecimal(profcanal) == medidaZLong)
							{
								Larguracanal = Convert.ToDecimal(novaEscritaProfLargCanal[j].ToString().Split('=')[1]);
							}
						}

						novaEscritaSCX.EscritaRanhuraSerra(NovoNomeSCX_B, novoProcessamento.ValorDZ, novoProcessamento.XLong, novoProcessamento.YLong, novoProcessamento.XFLong, novoProcessamento.ZLong, NbFaceB, Larguracanal);
					}
					else if (leituratotalxxlB[i].StartsWith("FRESATURA_LIN")) //Escrita Groove Fresa
					{
						novoProcessamento.LeituraFresa(leituratotalxxlB[i]);
						decimal ladocompensacao = novoProcessamento.CFresature;

						if (ladocompensacao == 1) //Esq
						{
							Carachineslado = "右";
						}
						else if (ladocompensacao == 2) //Dir
						{
							Carachineslado = "左";
						}
						else
						{
							Carachineslado = "中";
						}

						for (int j = 0; j < novaEscritaProfLargCanal.Count; j++)
						{
							decimal medidaZLong = novoProcessamento.ZFresature;
							string profcanal = novaEscritaProfLargCanal[j].ToString().Split('=')[0];

							if (Convert.ToDecimal(profcanal) == medidaZLong)
							{
								Larguracanal = Convert.ToDecimal(novaEscritaProfLargCanal[j].ToString().Split('=')[1]);
							}
						}

						novaEscritaSCX.EscritaFresa(NovoNomeSCX_B, novoProcessamento.ValorDZ, (novoProcessamento.ValorDX - novoProcessamento.XFresature), novoProcessamento.YFresature, (novoProcessamento.ValorDX - novoProcessamento.XFFresature), novoProcessamento.YFFresature, novoProcessamento.ZFresature, NbFaceB, Larguracanal, Carachineslado);

					}
					else if (leituratotalxxlB[i].StartsWith("TASCA_RET")) //Cavidade R
					{
						novoProcessamento.LeituraTascaRet(leituratotalxxlB[i]);
						novaEscritaSCX.EscritaTasca_RetInf(NovoNomeSCX_B, novoProcessamento.ValorDX, novoProcessamento.ValorDY, novoProcessamento.XTascaRet, novoProcessamento.YTascaRet, novoProcessamento.LTascaRet, novoProcessamento.HTascaRet, novoProcessamento.ZTascaRet, NbFaceB);

					}
					else if (leituratotalxxlB[i].StartsWith("TASCA_CIR")) //Cavidade c
					{
						novoProcessamento.LeituraTascaCir(leituratotalxxlB[i]);
						novaEscritaSCX.EscritaTasca_CircInf(NovoNomeSCX_B, novoProcessamento.ValorDX, novoProcessamento.ValorDY, novoProcessamento.XTascaCirc, novoProcessamento.YTascaCirc, novoProcessamento.DTascaCirc, novoProcessamento.ZTascaCirc, NbFaceB);

					}
				}
			}

			foreach (var xxlFULL in listaSCXFULL)
			{
				novaEscritaSCX.EscritaRodape(xxlFULL); //Escrita rodape
			}

			foreach (var item in listaXXLFULL)
			{
				File.Delete(item); //Apaga XXl antigo
			}

			foreach (var item in listaINF)
			{
				File.Delete(item); //Apaga inf
			}

			return arquivosXXL;
		}
	}
}


#region Temp

#endregion