﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Globalization;
using System.Runtime.Remoting.Channels;
using System.Windows.Forms;
using System.Security.Policy;

namespace XXL_To_SCX_Nanxing_2To1
{
	internal class ProcessamentoLeitura
	{
		#region Cabecalho
		public decimal ValorDX { get; set; }
		public decimal ValorDY { get; set; }
		public decimal ValorDZ { get; set; }
		#endregion

		#region Furos
		private string XBO { get; set; }
		public decimal XFuro { get; set; }
		public decimal YFuro { get; set; }
		public decimal ZFuro { get; set; }
		private decimal XFuroTEMP { get; set; }
		private decimal YFuroTEMP { get; set; }
		private decimal ZFuroTEMP { get; set; }
		public decimal DepthFuroTEMP { get; set; }
		public decimal FFuro { get; set; }
		public decimal TipoFuro { get; set; }
		public decimal DFuro { get; set; }
		public string NFuro { get; set; }
		public decimal RFuro { get; set; }
		#endregion

		#region Long
		public string LONG { get; set; }
		public decimal XLong { get; set; }
		public decimal YLong { get; set; }
		public decimal XFLong { get; set; }
		public decimal ZLong { get; set; }
		#endregion

		#region FresatureLin
		public string FRESATURA_LIN { get; set; }
		public decimal XFresature { get; set; }
		public decimal YFresature { get; set; }
		public decimal XFFresature { get; set; }
		public decimal YFFresature { get; set; }
		public decimal ZFresature { get; set; }
		public decimal CFresature { get; set; }
		public decimal TFresature { get; set; }
		#endregion

		#region TascaC
		public string TASCA_Circ { get; set; }
		public decimal XTascaCirc { get; set; }
		public decimal YTascaCirc { get; set; }
		public decimal DTascaCirc { get; set; }
		public decimal ZTascaCirc { get; set; }
		public decimal TTascaCirc { get; set; }
		#endregion

		#region TascaR
		public string TASCA_Ret { get; set; }
		public decimal XTascaRet { get; set; }
		public decimal YTascaRet { get; set; }
		public decimal LTascaRet { get; set; }
		public decimal HTascaRet { get; set; }
		public decimal rTascaRet { get; set; }
		public decimal ZTascaRet { get; set; }
		public decimal TTascaRet { get; set; }
		#endregion

		#region ScassoR
		public string SCASSOR { get; set; }
		public decimal XScassor { get; set; }
		public decimal YScassor { get; set; }
		public decimal ZScassor { get; set; }
		public decimal HScassor { get; set; }
		public decimal IScassor { get; set; }
		public decimal TScassor { get; set; }
		public decimal FScassor { get; set; }
		public decimal xScassor { get; set; }
		public decimal yScassor { get; set; }
		public decimal rScassor { get; set; }
		public decimal sScassor { get; set; }
		#endregion

		#region ScassoC
		public string SCASSOC { get; set; }
		public decimal XScassoc { get; set; }
		public decimal YScassoc { get; set; }
		public decimal ZScassoc { get; set; }
		public decimal HScassoc { get; set; }
		public decimal IScassoc { get; set; }
		public decimal TScassoc { get; set; }
		public decimal FScassoc { get; set; }
		public decimal xScassoc { get; set; }
		public decimal sScassoc { get; set; }
		#endregion

		#region ChannelX
		public string CHANNELX { get; set; }
		public decimal XChannelX { get; set; }
		public decimal YChannelX { get; set; }
		public decimal ZChannelX { get; set; }
		public decimal sChannelX { get; set; }
		#endregion

		#region ChannelY
		public string CHANNELY { get; set; }
		public decimal XChannelY { get; set; }
		public decimal YChannelY { get; set; }
		public decimal ZChannelY { get; set; }
		public decimal sChannelY { get; set; }
		#endregion

		#region  XG0
		public string XG0 { get; set; }
		public decimal Xxg0 { get; set; }
		public decimal Yxg0 { get; set; }
		public decimal Zxg0 { get; set; }
		public string Fxg0 { get; set; }
		#endregion

		#region XL2P XA2R
		public string XL2P { get; set; }
		public string XA2R { get; set; }
		public decimal Xxl2p { get; set; }
		public decimal Yxl2p { get; set; }
		public decimal Zxl2p { get; set; }
		public decimal Xxa2r { get; set; }
		public decimal Yxa2r { get; set; }
		public decimal Zxa2r { get; set; }
		public decimal Rxa2r { get; set; }
		public decimal Gxa2r { get; set; }
		#endregion

		public string LeituraCabecalho(string cabecalho) //Cabecalho
		{
			string[] splitlinhaarraysplitCabecalho = cabecalho.Split(' ');

			for (int i = 0; i < splitlinhaarraysplitCabecalho.Length; i++)
			{
				if (splitlinhaarraysplitCabecalho[i].StartsWith("DX="))
				{
					string valorDX = splitlinhaarraysplitCabecalho[i].Replace("DX=", "");
					decimal valorRealDX = decimal.Parse(valorDX, CultureInfo.InstalledUICulture);
					ValorDX = valorRealDX;
				}

				if (splitlinhaarraysplitCabecalho[i].StartsWith("DY="))
				{
					string valorDY = splitlinhaarraysplitCabecalho[i].Replace("DY=", "");
					decimal valorRealDY = decimal.Parse(valorDY, CultureInfo.InstalledUICulture);
					ValorDY = valorRealDY;
				}

				if (splitlinhaarraysplitCabecalho[i].StartsWith("DZ="))
				{
					string valorDZ = splitlinhaarraysplitCabecalho[i].Replace("DZ=", "");
					decimal valorRealDZ = decimal.Parse(valorDZ, CultureInfo.InstalledUICulture);
					ValorDZ = valorRealDZ;
				}
			}

			return cabecalho;
		}

		public string LeituraXBO(string linhaarraysplitXBO) //Furo
		{
			string[] splitlinhaarraysplitXBO = linhaarraysplitXBO.Split(' ');

			for (int i = 0; i < splitlinhaarraysplitXBO.Length; i++)
			{
				if (splitlinhaarraysplitXBO[i].ToString().StartsWith("XBO"))
				{
					string valorXBO = splitlinhaarraysplitXBO[i];
					XBO = valorXBO;
				}
				else if (splitlinhaarraysplitXBO[i].ToString().StartsWith("X="))
				{
					string valorX = splitlinhaarraysplitXBO[i].Replace("X=", "");
					decimal valorRealX = decimal.Parse(valorX, CultureInfo.InstalledUICulture);
					XFuroTEMP = valorRealX;
				}
				else if (splitlinhaarraysplitXBO[i].ToString().StartsWith("Y="))
				{
					string valorY = splitlinhaarraysplitXBO[i].Replace("Y=", "");
					decimal valorRealY = decimal.Parse(valorY, CultureInfo.InstalledUICulture);
					YFuroTEMP = valorRealY;
				}
				else if (splitlinhaarraysplitXBO[i].ToString().StartsWith("Z="))
				{
					string valorZ = splitlinhaarraysplitXBO[i].Replace("Z=", "");
					decimal valorRealZ = decimal.Parse(valorZ, CultureInfo.InstalledUICulture);
					ZFuroTEMP = valorRealZ;
				}
				else if (splitlinhaarraysplitXBO[i].ToString().StartsWith("F="))
				{
					if (splitlinhaarraysplitXBO[i].ToString().StartsWith("F=1")) //Superior
					{
						FFuro = 5;
						TipoFuro = 2;
						XFuro = ValorDX - XFuroTEMP;
						YFuro = YFuroTEMP;
						DepthFuroTEMP = ZFuroTEMP;
					}
					else if (splitlinhaarraysplitXBO[i].ToString().StartsWith("F=6")) //Inferior
					{
						FFuro = 6;
						TipoFuro = 2;
						XFuro = ValorDX - XFuroTEMP;
						YFuro = ValorDY - YFuroTEMP;
						ZFuro = ZFuroTEMP;
					}
					else //Topo
					{
						if (splitlinhaarraysplitXBO[i].ToString().StartsWith("F=2")) //Topo direito
						{
							FFuro = 4;
							decimal YTempFuro = YFuroTEMP;
							XFuro = 0;
							YFuro = YTempFuro;
							ZFuro = XFuroTEMP;
							DepthFuroTEMP = ZFuroTEMP;
						}
						else if (splitlinhaarraysplitXBO[i].ToString().StartsWith("F=3")) //Topo esquerdo
						{
							FFuro = 3;
							decimal YTempFuro = YFuroTEMP;
							XFuro = ValorDX;
							YFuro = YTempFuro;
							ZFuro = XFuroTEMP;
							DepthFuroTEMP = ZFuroTEMP;
						}
						else if (splitlinhaarraysplitXBO[i].ToString().StartsWith("F=4")) //Topo inferior
						{
							FFuro = 1;
							decimal XTempFuro = ValorDX - XFuroTEMP;
							decimal YTempFuro = YFuroTEMP;
							XFuro = XTempFuro;
							YFuro = ValorDY;
							ZFuro = YTempFuro;
							DepthFuroTEMP = ZFuroTEMP;
						}
						else //Topo superior
						{
							FFuro = 2;
							decimal XTempFuro = ValorDX - XFuroTEMP;
							decimal YTempFuro = YFuroTEMP;
							XFuro = XTempFuro;
							YFuro = 0;
							ZFuro = YTempFuro;
							DepthFuroTEMP = ZFuroTEMP;
						}

						TipoFuro = 1;
					}
				}
				else if (splitlinhaarraysplitXBO[i].ToString().StartsWith("D="))
				{
					string valorD = splitlinhaarraysplitXBO[i].Replace("D=", "");
					decimal valorRealD = decimal.Parse(valorD, CultureInfo.InstalledUICulture);
					DFuro = valorRealD;
				}
				else if (splitlinhaarraysplitXBO[i].ToString().StartsWith("N="))
				{
					string valorN = splitlinhaarraysplitXBO[i].Replace("N=", "");
					NFuro = valorN;
				}
				else if (splitlinhaarraysplitXBO[i].ToString().StartsWith("R="))
				{
					string valorR = splitlinhaarraysplitXBO[i].Replace("R=", "");
					decimal valorRealR = decimal.Parse(valorR, CultureInfo.InstalledUICulture);
					RFuro = valorRealR;
				}
				else
				{
					return null;
				}
			}

			return linhaarraysplitXBO;
		}

		public string LeituraLong(string linhaarraysplitLong) //Canal Long
		{
			string[] splitlinhaarraysplitLONG = linhaarraysplitLong.Split(' ');

			for (int i = 0; i < splitlinhaarraysplitLONG.Length; i++)
			{
				if (splitlinhaarraysplitLONG[i].ToString().StartsWith("LONG"))
				{
					string valorLONG = splitlinhaarraysplitLONG[i];
					LONG = valorLONG;
				}
				else if (splitlinhaarraysplitLONG[i].ToString().StartsWith("X="))
				{
					string valorXLong = splitlinhaarraysplitLONG[i].Replace("X=", "");
					decimal valorXLongReal = decimal.Parse(valorXLong, CultureInfo.InstalledUICulture);
					XLong = valorXLongReal;
				}
				else if (splitlinhaarraysplitLONG[i].ToString().StartsWith("Y="))
				{
					string valorYLong = splitlinhaarraysplitLONG[i].Replace("Y=", "");
					decimal valorYLongReal = decimal.Parse(valorYLong, CultureInfo.InstalledUICulture);
					YLong = valorYLongReal;
				}
				else if (splitlinhaarraysplitLONG[i].ToString().StartsWith("x="))
				{
					string valorxLong = splitlinhaarraysplitLONG[i].Replace("x=", "");
					decimal valorxLongReal = decimal.Parse(valorxLong, CultureInfo.InstalledUICulture);
					XFLong = valorxLongReal;
				}
				else if (splitlinhaarraysplitLONG[i].ToString().StartsWith("Z="))
				{
					string valorZLong = splitlinhaarraysplitLONG[i].Replace("Z=", "");
					decimal valorZLongReal = decimal.Parse(valorZLong, CultureInfo.InstalledUICulture);
					ZLong = valorZLongReal;
				}
				else
				{
					return null;
				}
			}

			return linhaarraysplitLong;
		}

		public string LeituraFresa(string linhaarraysplitFresatureLine) //Canal Fresature
		{
			string[] splitlinhaarraysplitFRESATURE = linhaarraysplitFresatureLine.Split(' ');

			for (int i = 0; i < splitlinhaarraysplitFRESATURE.Length; i++)
			{
				if (splitlinhaarraysplitFRESATURE[i].ToString().StartsWith("FRESATURA_LIN"))
				{
					string valorFRESATURE = splitlinhaarraysplitFRESATURE[i];
					FRESATURA_LIN = valorFRESATURE;
				}
				else if (splitlinhaarraysplitFRESATURE[i].ToString().StartsWith("X="))
				{
					string valorXFRESATURE = splitlinhaarraysplitFRESATURE[i].Replace("X=", "");
					decimal valorXFRESATUREReal = decimal.Parse(valorXFRESATURE, CultureInfo.InstalledUICulture);
					XFresature = valorXFRESATUREReal;
				}
				else if (splitlinhaarraysplitFRESATURE[i].ToString().StartsWith("Y="))
				{
					string valorYFRESATURE = splitlinhaarraysplitFRESATURE[i].Replace("Y=", "");
					decimal valorYFRESATUREReal = decimal.Parse(valorYFRESATURE, CultureInfo.InstalledUICulture);
					YFresature = valorYFRESATUREReal;
				}
				else if (splitlinhaarraysplitFRESATURE[i].ToString().StartsWith("x="))
				{
					string valorxFRESATURE = splitlinhaarraysplitFRESATURE[i].Replace("x=", "");
					decimal valorxFRESATUREReal = decimal.Parse(valorxFRESATURE, CultureInfo.InstalledUICulture);
					XFFresature = valorxFRESATUREReal;
				}
				else if (splitlinhaarraysplitFRESATURE[i].ToString().StartsWith("y="))
				{
					string valoryFRESATURE = splitlinhaarraysplitFRESATURE[i].Replace("y=", "");
					decimal valoryFRESATUREReal = decimal.Parse(valoryFRESATURE, CultureInfo.InstalledUICulture);
					YFFresature = valoryFRESATUREReal;
				}
				else if (splitlinhaarraysplitFRESATURE[i].ToString().StartsWith("Z="))
				{
					string valorZFRESATURE = splitlinhaarraysplitFRESATURE[i].Replace("Z=", "");
					decimal valorZFRESATUREReal = decimal.Parse(valorZFRESATURE, CultureInfo.InstalledUICulture);
					ZFresature = valorZFRESATUREReal;
				}
				else if (splitlinhaarraysplitFRESATURE[i].ToString().StartsWith("C="))
				{
					string valorCFRESATURE = splitlinhaarraysplitFRESATURE[i].Replace("C=", "");
					decimal valorCFRESATUREReal = decimal.Parse(valorCFRESATURE, CultureInfo.InstalledUICulture);
					CFresature = valorCFRESATUREReal;
				}
				else if (splitlinhaarraysplitFRESATURE[i].ToString().StartsWith("T="))
				{
					string valorTFRESATURE = splitlinhaarraysplitFRESATURE[i].Replace("T=", "");
					decimal valorTFRESATUREReal = decimal.Parse(valorTFRESATURE, CultureInfo.InstalledUICulture);
					TFresature = valorTFRESATUREReal;
				}
				else
				{
					return null;
				}
			}

			return linhaarraysplitFresatureLine;
		}

		public string LeituraTascaCir(string linhaarraysplitTascaCirc) //Cavidade Circular
		{
			string[] splitlinhaarraysplitTASCA_CIRC = linhaarraysplitTascaCirc.Split(' ');

			for (int i = 0; i < splitlinhaarraysplitTASCA_CIRC.Length; i++)
			{
				if (splitlinhaarraysplitTASCA_CIRC[i].ToString().StartsWith("TASCA_CIR"))
				{
					string valorTASCA_CIRC = splitlinhaarraysplitTASCA_CIRC[i];
					TASCA_Circ = valorTASCA_CIRC;
				}
				else if (splitlinhaarraysplitTASCA_CIRC[i].ToString().StartsWith("X="))
				{
					string valorTASCA_CIRC = splitlinhaarraysplitTASCA_CIRC[i].Replace("X=", "");
					decimal valorXTASCA_CIRC = decimal.Parse(valorTASCA_CIRC, CultureInfo.InstalledUICulture);
					XTascaCirc = valorXTASCA_CIRC;
				}
				else if (splitlinhaarraysplitTASCA_CIRC[i].ToString().StartsWith("Y="))
				{
					string valorTASCA_CIRC = splitlinhaarraysplitTASCA_CIRC[i].Replace("Y=", "");
					decimal valorYTASCA_CIRC = decimal.Parse(valorTASCA_CIRC, CultureInfo.InstalledUICulture);
					YTascaCirc = valorYTASCA_CIRC;
				}
				else if (splitlinhaarraysplitTASCA_CIRC[i].ToString().StartsWith("D="))
				{
					string valorTASCA_CIRC = splitlinhaarraysplitTASCA_CIRC[i].Replace("D=", "");
					decimal valorLTASCA_CIRC = decimal.Parse(valorTASCA_CIRC, CultureInfo.InstalledUICulture);
					DTascaCirc = valorLTASCA_CIRC;
				}
				else if (splitlinhaarraysplitTASCA_CIRC[i].ToString().StartsWith("Z="))
				{
					string valorTASCA_CIRC = splitlinhaarraysplitTASCA_CIRC[i].Replace("Z=", "");
					decimal valorZTASCA_CIRC = decimal.Parse(valorTASCA_CIRC, CultureInfo.InstalledUICulture);
					ZTascaCirc = valorZTASCA_CIRC;
				}
				else if (splitlinhaarraysplitTASCA_CIRC[i].ToString().StartsWith("T="))
				{
					string valorTASCA_CIRC = splitlinhaarraysplitTASCA_CIRC[i].Replace("T=", "");
					decimal valorTTASCA_CIRC = decimal.Parse(valorTASCA_CIRC, CultureInfo.InstalledUICulture);
					TTascaCirc = valorTTASCA_CIRC;
				}
				else
				{
					return null;
				}
			}

			return linhaarraysplitTascaCirc;
		}

		public string LeituraTascaRet(string linhaarraysplitTascaRet) //Cavidade Retangular
		{
			string[] splitlinhaarraysplitTASCA_RET = linhaarraysplitTascaRet.Split(' ');

			for (int i = 0; i < splitlinhaarraysplitTASCA_RET.Length; i++)
			{
				if (splitlinhaarraysplitTASCA_RET[i].ToString().StartsWith("TASCA_RET"))
				{
					string valorTASCA_RET = splitlinhaarraysplitTASCA_RET[i];
					TASCA_Ret = valorTASCA_RET;
				}
				else if (splitlinhaarraysplitTASCA_RET[i].ToString().StartsWith("X="))
				{
					string valorTASCA_RET = splitlinhaarraysplitTASCA_RET[i].Replace("X=", "");
					decimal valorXTASCA_RET = decimal.Parse(valorTASCA_RET, CultureInfo.InstalledUICulture);
					XTascaRet = valorXTASCA_RET;
				}
				else if (splitlinhaarraysplitTASCA_RET[i].ToString().StartsWith("Y="))
				{
					string valorTASCA_RET = splitlinhaarraysplitTASCA_RET[i].Replace("Y=", "");
					decimal valorYTASCA_RET = decimal.Parse(valorTASCA_RET, CultureInfo.InstalledUICulture);
					YTascaRet = valorYTASCA_RET;
				}
				else if (splitlinhaarraysplitTASCA_RET[i].ToString().StartsWith("L="))
				{
					string valorTASCA_RET = splitlinhaarraysplitTASCA_RET[i].Replace("L=", "");
					decimal valorLTASCA_RET = decimal.Parse(valorTASCA_RET, CultureInfo.InstalledUICulture);
					LTascaRet = valorLTASCA_RET;
				}
				else if (splitlinhaarraysplitTASCA_RET[i].ToString().StartsWith("H="))
				{
					string valorTASCA_RET = splitlinhaarraysplitTASCA_RET[i].Replace("H=", "");
					decimal valorHTASCA_RET = decimal.Parse(valorTASCA_RET, CultureInfo.InstalledUICulture);
					HTascaRet = valorHTASCA_RET;
				}
				else if (splitlinhaarraysplitTASCA_RET[i].ToString().StartsWith("r="))
				{
					string valorTASCA_RET = splitlinhaarraysplitTASCA_RET[i].Replace("r=", "");
					decimal valorZTASCA_RET = decimal.Parse(valorTASCA_RET, CultureInfo.InstalledUICulture);
					rTascaRet = valorZTASCA_RET;
				}
				else if (splitlinhaarraysplitTASCA_RET[i].ToString().StartsWith("Z="))
				{
					string valorTASCA_RET = splitlinhaarraysplitTASCA_RET[i].Replace("Z=", "");
					decimal valorZTASCA_RET = decimal.Parse(valorTASCA_RET, CultureInfo.InstalledUICulture);
					ZTascaRet = valorZTASCA_RET;
				}
				else if (splitlinhaarraysplitTASCA_RET[i].ToString().StartsWith("T="))
				{
					string valorTASCA_RET = splitlinhaarraysplitTASCA_RET[i].Replace("T=", "");
					decimal valorTTASCA_RET = decimal.Parse(valorTASCA_RET, CultureInfo.InstalledUICulture);
					TTascaRet = valorTTASCA_RET;
				}
				else
				{
					return null;
				}
			}

			return linhaarraysplitTascaRet;
		}

		public string LeituraScassoR(string linhaarraysplitScassoR) //Cavidade SCASSOR Retangular
		{
			string[] splitlinhaarraysplitSCASSOR = linhaarraysplitScassoR.Split(' ');

			for (int i = 0; i < splitlinhaarraysplitSCASSOR.Length; i++)
			{
				if (splitlinhaarraysplitSCASSOR[i].ToString().StartsWith("SCASSOR"))
				{
					string valorSCASSOR = splitlinhaarraysplitSCASSOR[i];
					SCASSOR = valorSCASSOR;
				}
				else if (splitlinhaarraysplitSCASSOR[i].ToString().StartsWith("X="))
				{
					string valorSCASSOR = splitlinhaarraysplitSCASSOR[i].Replace("X=", "");
					decimal valorXSCASSOR = decimal.Parse(valorSCASSOR, CultureInfo.InstalledUICulture);
					XScassor = valorXSCASSOR;
				}
				else if (splitlinhaarraysplitSCASSOR[i].ToString().StartsWith("Y="))
				{
					string valorSCASSOR = splitlinhaarraysplitSCASSOR[i].Replace("Y=", "");
					decimal valorYSCASSOR = decimal.Parse(valorSCASSOR, CultureInfo.InstalledUICulture);
					YScassor = valorYSCASSOR;
				}
				else if (splitlinhaarraysplitSCASSOR[i].ToString().StartsWith("Z="))
				{
					string valorSCASSOR = splitlinhaarraysplitSCASSOR[i].Replace("Z=", "");
					decimal valorZSCASSOR = decimal.Parse(valorSCASSOR, CultureInfo.InstalledUICulture);
					ZScassor = valorZSCASSOR;
				}
				else if (splitlinhaarraysplitSCASSOR[i].ToString().StartsWith("H="))
				{
					string valorSCASSOR = splitlinhaarraysplitSCASSOR[i].Replace("H=", "");
					decimal valorHSCASSOR = decimal.Parse(valorSCASSOR, CultureInfo.InstalledUICulture);
					HScassor = valorHSCASSOR;
				}
				else if (splitlinhaarraysplitSCASSOR[i].ToString().StartsWith("I="))
				{
					string valorSCASSOR = splitlinhaarraysplitSCASSOR[i].Replace("I=", "");
					decimal valorISCASSOR = decimal.Parse(valorSCASSOR, CultureInfo.InstalledUICulture);
					IScassor = valorISCASSOR;
				}
				else if (splitlinhaarraysplitSCASSOR[i].ToString().StartsWith("T="))
				{
					string valorSCASSOR = splitlinhaarraysplitSCASSOR[i].Replace("T=", "");
					decimal valorTSCASSOR = decimal.Parse(valorSCASSOR, CultureInfo.InstalledUICulture);
					TScassor = valorTSCASSOR;
				}
				else if (splitlinhaarraysplitSCASSOR[i].ToString().StartsWith("F="))
				{
					string valorSCASSOR = splitlinhaarraysplitSCASSOR[i].Replace("F=", "");
					decimal valorFSCASSOR = decimal.Parse(valorSCASSOR, CultureInfo.InstalledUICulture);
					FScassor = valorFSCASSOR;
				}
				else if (splitlinhaarraysplitSCASSOR[i].ToString().StartsWith("x="))
				{
					string valorSCASSOR = splitlinhaarraysplitSCASSOR[i].Replace("x=", "");
					decimal valorxSCASSOR = decimal.Parse(valorSCASSOR, CultureInfo.InstalledUICulture);
					xScassor = valorxSCASSOR;
				}
				else if (splitlinhaarraysplitSCASSOR[i].ToString().StartsWith("y="))
				{
					string valorSCASSOR = splitlinhaarraysplitSCASSOR[i].Replace("y=", "");
					decimal valorySCASSOR = decimal.Parse(valorSCASSOR, CultureInfo.InstalledUICulture);
					yScassor = valorySCASSOR;
				}
				else if (splitlinhaarraysplitSCASSOR[i].ToString().StartsWith("r="))
				{
					string valorSCASSOR = splitlinhaarraysplitSCASSOR[i].Replace("r=", "");
					decimal valorZSCASSOR = decimal.Parse(valorSCASSOR, CultureInfo.InstalledUICulture);
					rScassor = valorZSCASSOR;
				}
				else if (splitlinhaarraysplitSCASSOR[i].ToString().StartsWith("s="))
				{
					string valorSCASSOR = splitlinhaarraysplitSCASSOR[i].Replace("s=", "");
					decimal valorSSCASSOR = decimal.Parse(valorSCASSOR, CultureInfo.InstalledUICulture);
					sScassor = valorSSCASSOR;
				}
				else
				{
					return null;
				}
			}

			return linhaarraysplitScassoR;
		}

		public string LeituraScassoC(string linhaarraysplitScassoC) //Cavidade SCASSOC Circular
		{
			string[] splitlinhaarraysplitSCASSOC = linhaarraysplitScassoC.Split(' ');

			for (int i = 0; i < splitlinhaarraysplitSCASSOC.Length; i++)
			{
				if (splitlinhaarraysplitSCASSOC[i].ToString().StartsWith("SCASSOC"))
				{
					string valorSCASSOC = splitlinhaarraysplitSCASSOC[i];
					SCASSOC = valorSCASSOC;
				}
				else if (splitlinhaarraysplitSCASSOC[i].ToString().StartsWith("X="))
				{
					string valorSCASSOC = splitlinhaarraysplitSCASSOC[i].Replace("X=", "");
					decimal valorXSCASSOC = decimal.Parse(valorSCASSOC, CultureInfo.InstalledUICulture);
					XScassoc = valorXSCASSOC;
				}
				else if (splitlinhaarraysplitSCASSOC[i].ToString().StartsWith("Y="))
				{
					string valorSCASSOC = splitlinhaarraysplitSCASSOC[i].Replace("Y=", "");
					decimal valorYSCASSOC = decimal.Parse(valorSCASSOC, CultureInfo.InstalledUICulture);
					YScassoc = valorYSCASSOC;
				}
				else if (splitlinhaarraysplitSCASSOC[i].ToString().StartsWith("Z="))
				{
					string valorSCASSOC = splitlinhaarraysplitSCASSOC[i].Replace("Z=", "");
					decimal valorZSCASSOC = decimal.Parse(valorSCASSOC, CultureInfo.InstalledUICulture);
					ZScassoc = valorZSCASSOC;
				}
				else if (splitlinhaarraysplitSCASSOC[i].ToString().StartsWith("H="))
				{
					string valorSCASSOC = splitlinhaarraysplitSCASSOC[i].Replace("H=", "");
					decimal valorHSCASSOC = decimal.Parse(valorSCASSOC, CultureInfo.InstalledUICulture);
					HScassoc = valorHSCASSOC;
				}
				else if (splitlinhaarraysplitSCASSOC[i].ToString().StartsWith("I="))
				{
					string valorSCASSOC = splitlinhaarraysplitSCASSOC[i].Replace("I=", "");
					decimal valorISCASSOC = decimal.Parse(valorSCASSOC, CultureInfo.InstalledUICulture);
					IScassoc = valorISCASSOC;
				}
				else if (splitlinhaarraysplitSCASSOC[i].ToString().StartsWith("T="))
				{
					string valorSCASSOC = splitlinhaarraysplitSCASSOC[i].Replace("T=", "");
					decimal valorTSCASSOC = decimal.Parse(valorSCASSOC, CultureInfo.InstalledUICulture);
					TScassoc = valorTSCASSOC;
				}
				else if (splitlinhaarraysplitSCASSOC[i].ToString().StartsWith("F="))
				{
					string valorSCASSOC = splitlinhaarraysplitSCASSOC[i].Replace("F=", "");
					decimal valorFSCASSOC = decimal.Parse(valorSCASSOC, CultureInfo.InstalledUICulture);
					FScassoc = valorFSCASSOC;
				}
				else if (splitlinhaarraysplitSCASSOC[i].ToString().StartsWith("x="))
				{
					string valorSCASSOC = splitlinhaarraysplitSCASSOC[i].Replace("x=", "");
					decimal valorxSCASSOC = decimal.Parse(valorSCASSOC, CultureInfo.InstalledUICulture);
					xScassoc = valorxSCASSOC;
				}
				else if (splitlinhaarraysplitSCASSOC[i].ToString().StartsWith("s="))
				{
					string valorSCASSOC = splitlinhaarraysplitSCASSOC[i].Replace("s=", "");
					decimal valorSSCASSOC = decimal.Parse(valorSCASSOC, CultureInfo.InstalledUICulture);
					sScassoc = valorSSCASSOC;
				}
				else
				{
					return null;
				}
			}

			return linhaarraysplitScassoC;
		}

		public string LeituraChannelX(string linhaarraysplitChannelX) //Canal CHANNELX
		{
			string[] splitlinhaarraysplitCHANNELX = linhaarraysplitChannelX.Split(' ');

			for (int i = 0; i < splitlinhaarraysplitCHANNELX.Length; i++)
			{
				if (splitlinhaarraysplitCHANNELX[i].ToString().StartsWith("CHANNELX"))
				{
					string valorCHANNELX = splitlinhaarraysplitCHANNELX[i];
					CHANNELX = valorCHANNELX;
				}
				else if (splitlinhaarraysplitCHANNELX[i].ToString().StartsWith("X="))
				{
					string valorCHANNELX = splitlinhaarraysplitCHANNELX[i].Replace("X=", "");
					decimal valorXCHANNELX = decimal.Parse(valorCHANNELX, CultureInfo.InstalledUICulture);
					XChannelX = valorXCHANNELX;
				}
				else if (splitlinhaarraysplitCHANNELX[i].ToString().StartsWith("Y="))
				{
					string valorCHANNELX = splitlinhaarraysplitCHANNELX[i].Replace("Y=", "");
					decimal valorYCHANNELX = decimal.Parse(valorCHANNELX, CultureInfo.InstalledUICulture);
					YChannelX = valorYCHANNELX;
				}
				else if (splitlinhaarraysplitCHANNELX[i].ToString().StartsWith("Z="))
				{
					string valorCHANNELX = splitlinhaarraysplitCHANNELX[i].Replace("Z=", "");
					decimal valorZCHANNELX = decimal.Parse(valorCHANNELX, CultureInfo.InstalledUICulture);
					ZChannelX = valorZCHANNELX;
				}
				else if (splitlinhaarraysplitCHANNELX[i].ToString().StartsWith("I=") || splitlinhaarraysplitCHANNELX[i].ToString().StartsWith("T=") || splitlinhaarraysplitCHANNELX[i].ToString().StartsWith("F=") || splitlinhaarraysplitCHANNELX[i].ToString().StartsWith("r=")){}
				else if (splitlinhaarraysplitCHANNELX[i].ToString().StartsWith("s="))
				{
					string valorCHANNELX = splitlinhaarraysplitCHANNELX[i].Replace("s=", "");
					decimal valorSCHANNELX = decimal.Parse(valorCHANNELX, CultureInfo.InstalledUICulture);
					sChannelX = valorSCHANNELX;
				}
				else
				{
					return null;
				}
			}

			return linhaarraysplitChannelX;
		}

		public string LeituraChannelY(string linhaarraysplitChannelY) //Canal CHANNELY
		{
			string[] splitlinhaarraysplitCHANNELY = linhaarraysplitChannelY.Split(' ');

			for (int i = 0; i < splitlinhaarraysplitCHANNELY.Length; i++)
			{
				if (splitlinhaarraysplitCHANNELY[i].ToString().StartsWith("CHANNELY"))
				{
					string valorCHANNELY = splitlinhaarraysplitCHANNELY[i];
					CHANNELY = valorCHANNELY;
				}
				else if (splitlinhaarraysplitCHANNELY[i].ToString().StartsWith("X="))
				{
					string valorCHANNELY = splitlinhaarraysplitCHANNELY[i].Replace("X=", "");
					decimal valorXCHANNELY = decimal.Parse(valorCHANNELY, CultureInfo.InstalledUICulture);
					XChannelY = valorXCHANNELY;
				}
				else if (splitlinhaarraysplitCHANNELY[i].ToString().StartsWith("Y="))
				{
					string valorCHANNELY = splitlinhaarraysplitCHANNELY[i].Replace("Y=", "");
					decimal valorYCHANNELY = decimal.Parse(valorCHANNELY, CultureInfo.InstalledUICulture);
					YChannelY = valorYCHANNELY;
				}
				else if (splitlinhaarraysplitCHANNELY[i].ToString().StartsWith("Z="))
				{
					string valorCHANNELY = splitlinhaarraysplitCHANNELY[i].Replace("Z=", "");
					decimal valorZCHANNELY = decimal.Parse(valorCHANNELY, CultureInfo.InstalledUICulture);
					ZChannelY = valorZCHANNELY;
				}
				else if (splitlinhaarraysplitCHANNELY[i].ToString().StartsWith("I=") || splitlinhaarraysplitCHANNELY[i].ToString().StartsWith("T=") || splitlinhaarraysplitCHANNELY[i].ToString().StartsWith("F=") || splitlinhaarraysplitCHANNELY[i].ToString().StartsWith("r=")) { }
				else if (splitlinhaarraysplitCHANNELY[i].ToString().StartsWith("s="))
				{
					string valorCHANNELY = splitlinhaarraysplitCHANNELY[i].Replace("s=", "");
					decimal valorSCHANNELY = decimal.Parse(valorCHANNELY, CultureInfo.InstalledUICulture);
					sChannelY = valorSCHANNELY;
				}
				else
				{
					return null;
				}
			}

			return linhaarraysplitChannelY;
		}

		public string LeituraXG0(string linhaarraysplitXG0) //Linha XG0
		{
			string[] splitlinhaarraysplitXG0 = linhaarraysplitXG0.Split(' ');

			for (int i = 0; i < splitlinhaarraysplitXG0.Length; i++)
			{
				if (splitlinhaarraysplitXG0[i].ToString().StartsWith("XG0"))
				{
					string valorXG0 = splitlinhaarraysplitXG0[i];
					XG0 = valorXG0;
				}
				else if (1 == 1)
				{

				}
			}
			return linhaarraysplitXG0;
		}
		
		public string LeituraXL2P(string linhaarraysplitXL2P) //Linha XL2P
		{
			string[] splitlinhaarraysplitXL2P = linhaarraysplitXL2P.Split(' ');

			for (int i = 0; i < splitlinhaarraysplitXL2P.Length; i++)
			{
				if (splitlinhaarraysplitXL2P[i].ToString().StartsWith("XL2P"))
				{
					string valorXL2P = splitlinhaarraysplitXL2P[i];
					XL2P = valorXL2P;
				}
				else if (1==1)
				{

				}
			}
			return linhaarraysplitXL2P;
		}

		public string LeituraXAR2(string linhaarraysplitXAR2) //Linha XAR2
		{
			string[] splitlinhaarraysplitXAR2 = linhaarraysplitXAR2.Split(' ');

			for (int i = 0; i < splitlinhaarraysplitXAR2.Length; i++)
			{
				if (splitlinhaarraysplitXAR2[i].ToString().StartsWith("XA2R"))
				{
					string valorXA2R = splitlinhaarraysplitXAR2[i];
					XA2R = valorXA2R;
				}
				else if (1 == 1)
				{

				}
			}
			return linhaarraysplitXAR2;
		}

		public string Nulo()
		{
			return null;
		}
	}
}
