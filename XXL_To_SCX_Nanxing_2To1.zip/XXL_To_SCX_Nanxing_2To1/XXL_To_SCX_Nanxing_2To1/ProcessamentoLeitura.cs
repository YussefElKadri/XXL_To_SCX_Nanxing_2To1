﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Globalization;

namespace XXL_To_SCX_Nanxing_2To1
{
	internal class ProcessamentoLeitura
	{
		#region Cabecalho
		public decimal ValorDX { get; set; }
		public decimal ValorDY { get; set; }
		public decimal ValorDZ { get; set; }

		#endregion

		#region Furos
		private string XBO { get; set; }
		public decimal XFuro { get; set; }
		public decimal YFuro { get; set; }
		public decimal ZFuro { get; set; }
		private decimal XFuroTEMP { get; set; }
		private decimal YFuroTEMP { get; set; }
		private decimal ZFuroTEMP { get; set; }
		public decimal DepthFuroTEMP { get; set; }
		public decimal FFuro { get; set; }
		public decimal TipoFuro { get; set; }
		public decimal DFuro { get; set; }
		public string NFuro { get; set; }
		public decimal RFuro { get; set; }

		#endregion

		#region Long
		public string LONG { get; set; }
		public decimal XLong { get; set; }
		public decimal YLong { get; set; }
		public decimal XFLong { get; set; }
		public decimal ZLong { get; set; }
		#endregion

		#region FresatureLin
		public string FRESATURA_LIN { get; set; }
		public decimal XFresature { get; set; }
		public decimal YFresature { get; set; }
		public decimal XFFresature { get; set; }
		public decimal YFFresature { get; set; }
		public decimal ZFresature { get; set; }
		public decimal CFresature { get; set; }
		public decimal TFresature { get; set; }
		#endregion

		#region TascaC
		public string TASCA_Circ { get; set; }
		public decimal XTascaCirc { get; set; }
		public decimal YTascaCirc { get; set; }
		public decimal DTascaCirc { get; set; }
		public decimal ZTascaCirc { get; set; }
		public decimal TTascaCirc { get; set; }
		#endregion

		#region TascaR
		public string TASCA_Ret { get; set; }
		public decimal XTascaRet { get; set; }
		public decimal YTascaRet { get; set; }
		public decimal LTascaRet { get; set; }
		public decimal HTascaRet { get; set; }
		public decimal rTascaRet { get; set; }
		public decimal ZTascaRet { get; set; }
		public decimal TTascaRet { get; set; }
		#endregion
		public string LeituraCabecalho(string cabecalho) //Cabecalho
		{
			string[] splitlinhaarraysplitCabecalho = cabecalho.Split(' ');

			for (int i = 0; i < splitlinhaarraysplitCabecalho.Length; i++)
			{
				if (splitlinhaarraysplitCabecalho[i].StartsWith("DX="))
				{
					string valorDX = splitlinhaarraysplitCabecalho[i].Replace("DX=", "");
					decimal valorRealDX = decimal.Parse(valorDX, CultureInfo.InstalledUICulture);
					ValorDX = valorRealDX;
				}

				if (splitlinhaarraysplitCabecalho[i].StartsWith("DY="))
				{
					string valorDY = splitlinhaarraysplitCabecalho[i].Replace("DY=", "");
					decimal valorRealDY = decimal.Parse(valorDY, CultureInfo.InstalledUICulture);
					ValorDY = valorRealDY;
				}

				if (splitlinhaarraysplitCabecalho[i].StartsWith("DZ="))
				{
					string valorDZ = splitlinhaarraysplitCabecalho[i].Replace("DZ=", "");
					decimal valorRealDZ = decimal.Parse(valorDZ, CultureInfo.InstalledUICulture);
					ValorDZ = valorRealDZ;
				}
			}

			return cabecalho;
		}
		public string LeituraXBO(string linhaarraysplitXBO) //Furo
		{
			string[] splitlinhaarraysplitXBO = linhaarraysplitXBO.Split(' ');

			for (int i = 0; i < splitlinhaarraysplitXBO.Length; i++)
			{
				if (splitlinhaarraysplitXBO[i].ToString().StartsWith("XBO"))
				{
					string valorXBO = splitlinhaarraysplitXBO[i];
					XBO = valorXBO;
				}
				else if (splitlinhaarraysplitXBO[i].ToString().StartsWith("X="))
				{
					string valorX = splitlinhaarraysplitXBO[i].Replace("X=", "");
					decimal valorRealX = decimal.Parse(valorX, CultureInfo.InstalledUICulture);
					XFuroTEMP = valorRealX;
				}
				else if (splitlinhaarraysplitXBO[i].ToString().StartsWith("Y="))
				{
					string valorY = splitlinhaarraysplitXBO[i].Replace("Y=", "");
					decimal valorRealY = decimal.Parse(valorY, CultureInfo.InstalledUICulture);
					YFuroTEMP = valorRealY;
				}
				else if (splitlinhaarraysplitXBO[i].ToString().StartsWith("Z="))
				{
					string valorZ = splitlinhaarraysplitXBO[i].Replace("Z=", "");
					decimal valorRealZ = decimal.Parse(valorZ, CultureInfo.InstalledUICulture);
					ZFuroTEMP = valorRealZ;
				}
				else if (splitlinhaarraysplitXBO[i].ToString().StartsWith("F="))
				{
					if (splitlinhaarraysplitXBO[i].ToString().StartsWith("F=1")) //Superior
					{
						FFuro = 5;
						TipoFuro = 2;
						XFuro = ValorDX - XFuroTEMP;
						YFuro = YFuroTEMP;
						DepthFuroTEMP = ZFuroTEMP;
					}
					else if (splitlinhaarraysplitXBO[i].ToString().StartsWith("F=6")) //Inferior
					{
						FFuro = 6;
						TipoFuro = 2;
						XFuro = ValorDX - XFuroTEMP;
						YFuro = ValorDY - YFuroTEMP;
						ZFuro = ZFuroTEMP;
					}
					else //Topo
					{
						if (splitlinhaarraysplitXBO[i].ToString().StartsWith("F=2")) //Topo direito
						{
							FFuro = 4;
							decimal YTempFuro = YFuroTEMP;
							XFuro = 0;
							YFuro = YTempFuro;
							ZFuro = XFuroTEMP;
							DepthFuroTEMP = ZFuroTEMP;
						}
						else if (splitlinhaarraysplitXBO[i].ToString().StartsWith("F=3")) //Topo esquerdo
						{
							FFuro = 3;
							decimal YTempFuro = YFuroTEMP;
							XFuro = ValorDX;
							YFuro = YTempFuro;
							ZFuro = XFuroTEMP;
							DepthFuroTEMP = ZFuroTEMP;
						}
						else if (splitlinhaarraysplitXBO[i].ToString().StartsWith("F=4")) //Topo inferior
						{
							FFuro = 1;
							decimal XTempFuro = ValorDX - XFuroTEMP;
							decimal YTempFuro = YFuroTEMP;
							XFuro = XTempFuro;
							YFuro = ValorDY;
							ZFuro = YTempFuro;
							DepthFuroTEMP = ZFuroTEMP;
						}
						else //Topo superior
						{
							FFuro = 2;
							decimal XTempFuro = ValorDX - XFuroTEMP;
							decimal YTempFuro = YFuroTEMP;
							XFuro = XTempFuro;
							YFuro = 0;
							ZFuro = YTempFuro;
							DepthFuroTEMP = ZFuroTEMP;
						}

						TipoFuro = 1;
					}
				}
				else if (splitlinhaarraysplitXBO[i].ToString().StartsWith("D="))
				{
					string valorD = splitlinhaarraysplitXBO[i].Replace("D=", "");
					decimal valorRealD = decimal.Parse(valorD, CultureInfo.InstalledUICulture);
					DFuro = valorRealD;
				}
				else if (splitlinhaarraysplitXBO[i].ToString().StartsWith("N="))
				{
					string valorN = splitlinhaarraysplitXBO[i].Replace("N=", "");
					NFuro = valorN;
				}
				else if (splitlinhaarraysplitXBO[i].ToString().StartsWith("R="))
				{
					string valorR = splitlinhaarraysplitXBO[i].Replace("R=", "");
					decimal valorRealR = decimal.Parse(valorR, CultureInfo.InstalledUICulture);
					RFuro = valorRealR;
				}
				else
				{
					return null;
				}
			}

			return linhaarraysplitXBO;
		}
		public string LeituraLong(string linhaarraysplitLong) //Canal Long
		{
			string[] splitlinhaarraysplitLONG = linhaarraysplitLong.Split(' ');

			for (int i = 0; i < splitlinhaarraysplitLONG.Length; i++)
			{
				if (splitlinhaarraysplitLONG[i].ToString().StartsWith("LONG"))
				{
					string valorLONG = splitlinhaarraysplitLONG[i];
					LONG = valorLONG;
				}
				else if (splitlinhaarraysplitLONG[i].ToString().StartsWith("X="))
				{
					string valorXLong = splitlinhaarraysplitLONG[i].Replace("X=", "");
					decimal valorXLongReal = decimal.Parse(valorXLong, CultureInfo.InstalledUICulture);
					XLong = valorXLongReal;
				}
				else if (splitlinhaarraysplitLONG[i].ToString().StartsWith("Y="))
				{
					string valorYLong = splitlinhaarraysplitLONG[i].Replace("Y=", "");
					decimal valorYLongReal = decimal.Parse(valorYLong, CultureInfo.InstalledUICulture);
					YLong = valorYLongReal;
				}
				else if (splitlinhaarraysplitLONG[i].ToString().StartsWith("x="))
				{
					string valorxLong = splitlinhaarraysplitLONG[i].Replace("x=", "");
					decimal valorxLongReal = decimal.Parse(valorxLong, CultureInfo.InstalledUICulture);
					XFLong = valorxLongReal;
				}
				else if (splitlinhaarraysplitLONG[i].ToString().StartsWith("Z="))
				{
					string valorZLong = splitlinhaarraysplitLONG[i].Replace("Z=", "");
					decimal valorZLongReal = decimal.Parse(valorZLong, CultureInfo.InstalledUICulture);
					ZLong = valorZLongReal;
				}
				else
				{
					return null;
				}
			}

			return linhaarraysplitLong;
		}
		public string LeituraFresa(string linhaarraysplitFresatureLine) //Canal Fresature
		{
			string[] splitlinhaarraysplitFRESATURE = linhaarraysplitFresatureLine.Split(' ');

			for (int i = 0; i < splitlinhaarraysplitFRESATURE.Length; i++)
			{
				if (splitlinhaarraysplitFRESATURE[i].ToString().StartsWith("FRESATURA_LIN"))
				{
					string valorFRESATURE = splitlinhaarraysplitFRESATURE[i];
					FRESATURA_LIN = valorFRESATURE;
				}
				else if (splitlinhaarraysplitFRESATURE[i].ToString().StartsWith("X="))
				{
					string valorXFRESATURE = splitlinhaarraysplitFRESATURE[i].Replace("X=", "");
					decimal valorXFRESATUREReal = decimal.Parse(valorXFRESATURE, CultureInfo.InstalledUICulture);
					XFresature = valorXFRESATUREReal;
				}
				else if (splitlinhaarraysplitFRESATURE[i].ToString().StartsWith("Y="))
				{
					string valorYFRESATURE = splitlinhaarraysplitFRESATURE[i].Replace("Y=", "");
					decimal valorYFRESATUREReal = decimal.Parse(valorYFRESATURE, CultureInfo.InstalledUICulture);
					YFresature = valorYFRESATUREReal;
				}
				else if (splitlinhaarraysplitFRESATURE[i].ToString().StartsWith("x="))
				{
					string valorxFRESATURE = splitlinhaarraysplitFRESATURE[i].Replace("x=", "");
					decimal valorxFRESATUREReal = decimal.Parse(valorxFRESATURE, CultureInfo.InstalledUICulture);
					XFFresature = valorxFRESATUREReal;
				}
				else if (splitlinhaarraysplitFRESATURE[i].ToString().StartsWith("y="))
				{
					string valoryFRESATURE = splitlinhaarraysplitFRESATURE[i].Replace("y=", "");
					decimal valoryFRESATUREReal = decimal.Parse(valoryFRESATURE, CultureInfo.InstalledUICulture);
					YFFresature = valoryFRESATUREReal;
				}
				else if (splitlinhaarraysplitFRESATURE[i].ToString().StartsWith("Z="))
				{
					string valorZFRESATURE = splitlinhaarraysplitFRESATURE[i].Replace("Z=", "");
					decimal valorZFRESATUREReal = decimal.Parse(valorZFRESATURE, CultureInfo.InstalledUICulture);
					ZFresature = valorZFRESATUREReal;
				}
				else if (splitlinhaarraysplitFRESATURE[i].ToString().StartsWith("C="))
				{
					string valorCFRESATURE = splitlinhaarraysplitFRESATURE[i].Replace("C=", "");
					decimal valorCFRESATUREReal = decimal.Parse(valorCFRESATURE, CultureInfo.InstalledUICulture);
					CFresature = valorCFRESATUREReal;
				}
				else if (splitlinhaarraysplitFRESATURE[i].ToString().StartsWith("T="))
				{
					string valorTFRESATURE = splitlinhaarraysplitFRESATURE[i].Replace("T=", "");
					decimal valorTFRESATUREReal = decimal.Parse(valorTFRESATURE, CultureInfo.InstalledUICulture);
					TFresature = valorTFRESATUREReal;
				}
				else
				{
					return null;
				}
			}

			return linhaarraysplitFresatureLine;
		}
		public string LeituraTascaCir(string linhaarraysplitTascaCirc) //Cavidade Circular
		{
			string[] splitlinhaarraysplitTASCA_CIRC = linhaarraysplitTascaCirc.Split(' ');

			for (int i = 0; i < splitlinhaarraysplitTASCA_CIRC.Length; i++)
			{
				if (splitlinhaarraysplitTASCA_CIRC[i].ToString().StartsWith("TASCA_CIR"))
				{
					string valorTASCA_CIRC = splitlinhaarraysplitTASCA_CIRC[i];
					TASCA_Circ = valorTASCA_CIRC;
				}
				else if (splitlinhaarraysplitTASCA_CIRC[i].ToString().StartsWith("X="))
				{
					string valorTASCA_CIRC = splitlinhaarraysplitTASCA_CIRC[i].Replace("X=", "");
					decimal valorXTASCA_CIRC = decimal.Parse(valorTASCA_CIRC, CultureInfo.InstalledUICulture);
					XTascaCirc = valorXTASCA_CIRC;
				}
				else if (splitlinhaarraysplitTASCA_CIRC[i].ToString().StartsWith("Y="))
				{
					string valorTASCA_CIRC = splitlinhaarraysplitTASCA_CIRC[i].Replace("Y=", "");
					decimal valorYTASCA_CIRC = decimal.Parse(valorTASCA_CIRC, CultureInfo.InstalledUICulture);
					YTascaCirc = valorYTASCA_CIRC;
				}
				else if (splitlinhaarraysplitTASCA_CIRC[i].ToString().StartsWith("D="))
				{
					string valorTASCA_CIRC = splitlinhaarraysplitTASCA_CIRC[i].Replace("D=", "");
					decimal valorLTASCA_CIRC = decimal.Parse(valorTASCA_CIRC, CultureInfo.InstalledUICulture);
					DTascaCirc = valorLTASCA_CIRC;
				}
				else if (splitlinhaarraysplitTASCA_CIRC[i].ToString().StartsWith("Z="))
				{
					string valorTASCA_CIRC = splitlinhaarraysplitTASCA_CIRC[i].Replace("Z=", "");
					decimal valorZTASCA_CIRC = decimal.Parse(valorTASCA_CIRC, CultureInfo.InstalledUICulture);
					ZTascaCirc = valorZTASCA_CIRC;
				}
				else if (splitlinhaarraysplitTASCA_CIRC[i].ToString().StartsWith("T="))
				{
					string valorTASCA_CIRC = splitlinhaarraysplitTASCA_CIRC[i].Replace("T=", "");
					decimal valorTTASCA_CIRC = decimal.Parse(valorTASCA_CIRC, CultureInfo.InstalledUICulture);
					TTascaCirc = valorTTASCA_CIRC;
				}
				else
				{
					return null;
				}
			}

			return linhaarraysplitTascaCirc;
		}
		public string LeituraTascaRet(string linhaarraysplitTascaRet) //Cavidade Retangular
		{
			string[] splitlinhaarraysplitTASCA_RET = linhaarraysplitTascaRet.Split(' ');

			for (int i = 0; i < splitlinhaarraysplitTASCA_RET.Length; i++)
			{
				if (splitlinhaarraysplitTASCA_RET[i].ToString().StartsWith("TASCA_RET"))
				{
					string valorTASCA_RET = splitlinhaarraysplitTASCA_RET[i];
					TASCA_Ret = valorTASCA_RET;
				}
				else if (splitlinhaarraysplitTASCA_RET[i].ToString().StartsWith("X="))
				{
					string valorTASCA_RET = splitlinhaarraysplitTASCA_RET[i].Replace("X=", "");
					decimal valorXTASCA_RET = decimal.Parse(valorTASCA_RET, CultureInfo.InstalledUICulture);
					XTascaRet = valorXTASCA_RET;
				}
				else if (splitlinhaarraysplitTASCA_RET[i].ToString().StartsWith("Y="))
				{
					string valorTASCA_RET = splitlinhaarraysplitTASCA_RET[i].Replace("Y=", "");
					decimal valorYTASCA_RET = decimal.Parse(valorTASCA_RET, CultureInfo.InstalledUICulture);
					YTascaRet = valorYTASCA_RET;
				}
				else if (splitlinhaarraysplitTASCA_RET[i].ToString().StartsWith("L="))
				{
					string valorTASCA_RET = splitlinhaarraysplitTASCA_RET[i].Replace("L=", "");
					decimal valorLTASCA_RET = decimal.Parse(valorTASCA_RET, CultureInfo.InstalledUICulture);
					LTascaRet = valorLTASCA_RET;
				}
				else if (splitlinhaarraysplitTASCA_RET[i].ToString().StartsWith("H="))
				{
					string valorTASCA_RET = splitlinhaarraysplitTASCA_RET[i].Replace("H=", "");
					decimal valorHTASCA_RET = decimal.Parse(valorTASCA_RET, CultureInfo.InstalledUICulture);
					HTascaRet = valorHTASCA_RET;
				}
				else if (splitlinhaarraysplitTASCA_RET[i].ToString().StartsWith("r="))
				{
					Nulo();
				}
				else if (splitlinhaarraysplitTASCA_RET[i].ToString().StartsWith("Z="))
				{
					string valorTASCA_RET = splitlinhaarraysplitTASCA_RET[i].Replace("Z=", "");
					decimal valorZTASCA_RET = decimal.Parse(valorTASCA_RET, CultureInfo.InstalledUICulture);
					ZTascaRet = valorZTASCA_RET;
				}
				else if (splitlinhaarraysplitTASCA_RET[i].ToString().StartsWith("T="))
				{
					string valorTASCA_RET = splitlinhaarraysplitTASCA_RET[i].Replace("T=", "");
					decimal valorTTASCA_RET = decimal.Parse(valorTASCA_RET, CultureInfo.InstalledUICulture);
					TTascaRet = valorTTASCA_RET;
				}
				else
				{
					return null;
				}
			}

			return linhaarraysplitTascaRet;
		}
		public string Nulo()
		{
			return null;
		}
	}
}
