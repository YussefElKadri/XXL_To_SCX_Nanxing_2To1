﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace XXL_To_SCX_Nanxing_2To1
{
	internal class EscritaLeituraToolCfg
	{
		public List<string> dadoscanal = new List<string>();
		private readonly string pastaCfg = "C:\\_TopSolid_Nanxing\\";
		private readonly string arquivoCfg = "Nanxing.tools";

		public void CriaPastaArquivoCFGTool()
		{
			Directory.CreateDirectory(pastaCfg);
			string aqruivoCfgFinal = pastaCfg + @"\" + arquivoCfg;

			if (!File.Exists(aqruivoCfgFinal))
			{
				StreamWriter escritaCFG = new StreamWriter(aqruivoCfgFinal);
				{
					escritaCFG.WriteLine("TABELA DE PARA PROF x LARG CANAL E REBAIXO.\nPREENCHER COM PROF ##2 CASAS DECIMAIS=LARG >> 7.00=10");
					escritaCFG.WriteLine("7.00=7");
					escritaCFG.WriteLine("7.10=19");
					escritaCFG.WriteLine("7.20=15.8");
					escritaCFG.WriteLine("15.00=15");
				}
				escritaCFG.Dispose();
				escritaCFG.Close();
			}
			else
			{
				string arquivo = aqruivoCfgFinal;
				string[] leituraarquivo = File.ReadAllLines(arquivo);

				for (int i = 2; i < leituraarquivo.Length; i++)
				{
					string medidacanal = leituraarquivo[i];
					dadoscanal.Add(medidacanal);
				}
			}
		}
	}
}


#region temp

#endregion