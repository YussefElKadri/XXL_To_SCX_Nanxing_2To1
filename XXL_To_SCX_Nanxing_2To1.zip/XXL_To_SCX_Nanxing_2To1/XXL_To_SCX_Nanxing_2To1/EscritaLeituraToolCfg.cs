﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace XXL_To_SCX_Nanxing_2To1
{
	internal class EscritaLeituraToolCfg
	{
		public List<string> dadoscanallarg = new List<string>();
		public List<string> dadospassadasz = new List<string>();
		private readonly string pastaCfg = "C:\\_TopSolid_Nanxing\\";
		private readonly string arquivoCfglargura = "LargurasOperacoes.tools";
		private readonly string arquivoCfgpassadaz = "PassadasVerticais.tools";

		public void CriaPastaArquivoCFGTool()
		{
			Directory.CreateDirectory(pastaCfg);
			string aqruivoCfgFinalLargura = pastaCfg + @"\" + arquivoCfglargura;
			string aqruivoCfgFinalPassadas = pastaCfg + @"\" + arquivoCfgpassadaz;

			if (!File.Exists(aqruivoCfgFinalLargura)) // Largura x prof
			{
				StreamWriter escritaCFGlargura = new StreamWriter(aqruivoCfgFinalLargura);
				{
					escritaCFGlargura.WriteLine("TABELA DE PARA PROF x LARG CANAL E REBAIXO.\nPREENCHER COM PROF ##2 CASAS DECIMAIS=LARG >> 7.00=10");
					escritaCFGlargura.WriteLine("7.00=7");
					escritaCFGlargura.WriteLine("7.10=19");
					escritaCFGlargura.WriteLine("7.20=15.8");
					escritaCFGlargura.WriteLine("15.00=15");
				}
				escritaCFGlargura.Dispose();
				escritaCFGlargura.Close();
			}
			else
			{
				string arquivo = aqruivoCfgFinalLargura;
				string[] leituraarquivo = File.ReadAllLines(arquivo);

				for (int i = 2; i < leituraarquivo.Length; i++)
				{
					string medidacanal = leituraarquivo[i];
					dadoscanallarg.Add(medidacanal);
				}
			}

			if (!File.Exists(aqruivoCfgFinalPassadas)) /// Passadas Z
			{
				StreamWriter escritaCFGpassadasz = new StreamWriter(aqruivoCfgFinalPassadas);
				{
					escritaCFGpassadasz.WriteLine("TABELA PASSADAS AXIAIS DA OPERAÇÃO.\nPREENCHER COM ESP PEÇA = NB PASSADAS >> 15=2, 18=2, 25=3...");
					escritaCFGpassadasz.WriteLine("15.5=2");
					escritaCFGpassadasz.WriteLine("18.5=2");
					escritaCFGpassadasz.WriteLine("25.5=3");
				}
				escritaCFGpassadasz.Dispose();
				escritaCFGpassadasz.Close();
			}
			else
			{
				string arquivo = aqruivoCfgFinalPassadas	;
				string[] leituraarquivo = File.ReadAllLines(arquivo);

				for (int i = 2; i < leituraarquivo.Length; i++)
				{
					string medidacanal = leituraarquivo[i];
					dadospassadasz.Add(medidacanal);
				}
			}
		}

	}
}


#region temp

#endregion