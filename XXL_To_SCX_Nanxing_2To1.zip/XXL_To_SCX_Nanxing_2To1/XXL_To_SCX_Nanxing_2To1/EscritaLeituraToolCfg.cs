﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace XXL_To_SCX_Nanxing_2To1
{
	internal class EscritaLeituraToolCfg
	{
		public decimal DiametroToolSup { get; set; }
		public decimal DiametroToolInf { get; set; }

		private readonly string pastaCfg = "C:\\_TopSolid_Nanxing\\";
		private readonly string arquivoCfg = "Nanxing.tools";

		public void CriaPastaArquivoCFGTool()
		{
			Directory.CreateDirectory(pastaCfg);
			string aqruivoCfgFinal = pastaCfg + @"\" + arquivoCfg;

			if (!File.Exists(aqruivoCfgFinal))
			{
				StreamWriter escritaCFG = new StreamWriter(aqruivoCfgFinal);
				{
					escritaCFG.WriteLine("tool_dia_sup=6");
					escritaCFG.WriteLine("tool_dia_inf=6");
				}
				escritaCFG.Dispose();
				escritaCFG.Close();
			}
			else
			{
				StreamReader leituraCFG = new StreamReader(aqruivoCfgFinal);
				{
					string[] leituraCFGTotal = File.ReadAllLines(aqruivoCfgFinal);

					for (int i = 0; i < leituraCFGTotal.Length; i++)
					{
						if (leituraCFGTotal[i].StartsWith("tool_dia_sup"))
						{
							string valorDiametroToolSup = leituraCFGTotal[i].Substring(13);
							DiametroToolSup = Convert.ToDecimal(valorDiametroToolSup);
						}
						else if (leituraCFGTotal[i].StartsWith("tool_dia_inf"))
						{
							string valorDiametroToolSup = leituraCFGTotal[i].Substring(13);
							DiametroToolInf = Convert.ToDecimal(valorDiametroToolSup);
						}
					}
				}
				leituraCFG.Dispose();
				leituraCFG.Close();
			}
		}
	}


}
