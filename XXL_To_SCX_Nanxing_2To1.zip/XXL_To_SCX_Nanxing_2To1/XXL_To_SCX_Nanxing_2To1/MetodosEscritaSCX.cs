﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Remoting.Channels;
using System.Runtime.Remoting.Metadata.W3cXsd2001;
using System.Text;
using System.Windows.Forms;
using System.Xml.Linq;

namespace XXL_To_SCX_Nanxing_2To1
{
	internal class MetodosEscritaSCX
	{
		public string EscritaCabecalho(string arquivoSCX, decimal Comp, decimal Larg, decimal Esp) //Metodo cabecalho
		{
			string nomeArquivo = new DirectoryInfo(arquivoSCX).Name;
			string nomeArquivoSemTipo = nomeArquivo.Replace(".SCX", "");

			StreamWriter escritaSCX = new StreamWriter(arquivoSCX,true) ;
			{
				escritaSCX.WriteLine("<?xml version=\"1.0\" encoding=\"utf-8\"?>");
				escritaSCX.WriteLine("<Root Cad=\"BuiltInCad\" version=\"2.0\">");
				escritaSCX.WriteLine("  <Project>");
				escritaSCX.WriteLine("    <Panels>");
				escritaSCX.WriteLine("      <Panel IsProduce=\"true\" ID=\"" + nomeArquivoSemTipo + "\" Name=\"" + nomeArquivoSemTipo + "\" Length=\"" + Comp.ToString() + "\" Width=\"" + Larg.ToString() + "\" Thickness=\"" + Esp.ToString() + "\" MachiningPoint=\"1\">");
				escritaSCX.WriteLine("        <Outline>");
				escritaSCX.WriteLine("          <Point X=\"" + Comp.ToString() + "\" Y=\"0\" />");
				escritaSCX.WriteLine("          <Point X=\"0\" Y=\"0\" />");
				escritaSCX.WriteLine("          <Point X=\"0\" Y=\"" + Larg.ToString() + "\" />");
				escritaSCX.WriteLine("          <Point X=\"" + Comp.ToString() + "\" Y=\"" + Larg.ToString() + "\" />");
				escritaSCX.WriteLine("        </Outline>");
				escritaSCX.WriteLine("        <Machines>");
			}
			escritaSCX.Close();
			escritaSCX.Dispose();

			return arquivoSCX;
		}

		public string EscritaRodape(string arquivoSCX) //Metodo rodape
		{
			StreamWriter escritaSCX = new StreamWriter(arquivoSCX, true);
			{
				escritaSCX.WriteLine("        </Machines>");
				escritaSCX.WriteLine("        <EdgeGroup X1=\"0\" Y1=\"0\">");
				escritaSCX.WriteLine("          <Edge Face=\"2\" Thickness=\"0\" Pre_Milling=\"0\" X=\"0\" Y=\"0\" CentralAngle=\"0\" />");
				escritaSCX.WriteLine("          <Edge Face=\"1\" Thickness=\"0\" Pre_Milling=\"0\" X=\"0\" Y=\"0\" CentralAngle=\"0\" />");
				escritaSCX.WriteLine("          <Edge Face=\"4\" Thickness=\"0\" Pre_Milling=\"0\" X=\"0\" Y=\"0\" CentralAngle=\"0\" />");
				escritaSCX.WriteLine("          <Edge Face=\"3\" Thickness=\"0\" Pre_Milling=\"0\" X=\"0\" Y=\"0\" CentralAngle=\"0\" />");
				escritaSCX.WriteLine("        </EdgeGroup>");
				escritaSCX.WriteLine("      </Panel>");
				escritaSCX.WriteLine("    </Panels>");
				escritaSCX.WriteLine("  </Project>");
				escritaSCX.WriteLine("</Root>");
			}
			escritaSCX.Close();
			escritaSCX.Dispose();

			return arquivoSCX;
		}

		public string EscritaFuro(string arquivoSCX, decimal espessuraPeca, decimal XFuro, decimal Yfuro, decimal DepthFuroTEMP, decimal ZFaceFuro, decimal DFuro, decimal FFuro, decimal TipoFuro) //Metodo furo
		{
			StreamWriter escritaSCX = new StreamWriter(arquivoSCX, true);
			{
				if ((DepthFuroTEMP >= espessuraPeca && FFuro == 5) || (DepthFuroTEMP >= espessuraPeca && FFuro == 6))
				{
					escritaSCX.WriteLine(value: $"          <Machining Type=\"{TipoFuro}\" IsGenCode=\"{2}\" Face=\"{5}\" X=\"{XFuro}\" Y=\"{Yfuro}\" Z=\"{ZFaceFuro}\" Diameter=\"{DFuro}\" Depth=\"{DepthFuroTEMP / 2}\" />");
					escritaSCX.WriteLine(value: $"          <Machining Type=\"{TipoFuro}\" IsGenCode=\"{2}\" Face=\"{6}\" X=\"{XFuro}\" Y=\"{Yfuro}\" Z=\"{ZFaceFuro}\" Diameter=\"{DFuro}\" Depth=\"{DepthFuroTEMP / 2}\" />");
				}
				else
				{
					escritaSCX.WriteLine(value: $"          <Machining Type=\"{TipoFuro}\" IsGenCode=\"{2}\" Face=\"{FFuro}\" X=\"{XFuro}\" Y=\"{Yfuro}\" Z=\"{ZFaceFuro}\" Diameter=\"{DFuro}\" Depth=\"{DepthFuroTEMP}\" />");
				}
			}
			escritaSCX.Close();
			escritaSCX.Dispose();

			return arquivoSCX;
		}

		public string EscritaRanhuraSerra(string arquivoSCX, decimal EspPeca, decimal XLong, decimal YLong, decimal xLong, decimal ZLong, int nbFace, decimal espTool) //Metodo long
		{
			StreamWriter escritaSCX = new StreamWriter(arquivoSCX, true);
			{
				escritaSCX.WriteLine(value: $"          <Machining Type=\"{4}\" IsGenCode=\"{2}\" Face=\"{nbFace}\" X=\"{XLong}\" Y=\"{YLong}\" Z=\"{EspPeca}\" EndX=\"{xLong}\" EndY=\"{YLong}\" EndZ=\"{EspPeca}\" Depth=\"{ZLong}\" Width=\"{espTool}\" ToolOffset=\"{'中'}\" />"); //Centro: 中 //Esquerdo: 左 //Direito: 右
			}

			escritaSCX.Close();
			escritaSCX.Dispose();

			return arquivoSCX;
		}

		public string EscritaFresa(string arquivoSCX, decimal EspPeca, decimal XFresature, decimal YFresature, decimal XEndFresature, decimal YEndFresature, decimal ZFresature, int NbFace, decimal espTool , string ladocomp) //Metodo fresature
		{
			StreamWriter escritaSCX = new StreamWriter(arquivoSCX, true);
			{
				escritaSCX.WriteLine(value: $"          <Machining Type=\"{4}\" IsGenCode=\"{2}\" Face=\"{NbFace}\" X=\"{XFresature}\" Y=\"{YFresature}\" Z=\"{EspPeca}\" EndX=\"{XEndFresature}\" EndY=\"{YEndFresature}\" EndZ=\"{EspPeca}\" Depth=\"{ZFresature}\" Width=\"{espTool}\" ToolOffset=\"{ladocomp}\" />"); //Centro: 中 //Esquerdo: 左 //Direito: 右
			}

			escritaSCX.Close();
			escritaSCX.Dispose();

			return arquivoSCX;
		}

		public string EscritaTasca_RetSupArc(decimal raio , string arquivoSCX, decimal ValorDx, decimal XTascaRet, decimal YTascaRet, decimal LTascaRet, decimal HTascaRet, decimal ZTascaRet, int NbFace) //Metodo sup_tasca_retArc
		{
			decimal xr = ValorDx - (XTascaRet - LTascaRet / 2);
			decimal yr = YTascaRet - HTascaRet / 2;

			StreamWriter escritaSCX = new StreamWriter(arquivoSCX, true);
			{
				escritaSCX.WriteLine(value: $"          <Machining Type=\"{3}\" IsGenCode=\"{2}\" Face=\"{NbFace}\" X=\"{xr - raio}\" Y=\"{yr}\" Depth=\"{ZTascaRet}\" Diameter=\"{10}\" ToolOffset=\"Undefined\" Pocket=\"{1}\" Closed=\"{1}\">");
				escritaSCX.WriteLine(value: $"            <MillPreDefinedRectangle Length=\"0\" Width=\"0\" X=\"0\" Y=\"0\" Z=\"0\" Radius=\"0\" CornerBotLeft=\"0\" CornerBotRight=\"0\" CornerTopLeft=\"0\" CornerTopRight=\"0\" />");
				escritaSCX.WriteLine(value: $"            <Lines>");
				escritaSCX.WriteLine(value: $"              <Line LineID=\"0\" EndX=\"{xr - raio}\" EndY=\"{yr}\" Angle=\"{0}\" />");
				escritaSCX.WriteLine(value: $"              <Line LineID=\"1\" EndX=\"{xr - LTascaRet + raio}\" EndY=\"{yr}\" Angle=\"{0}\" />");
				escritaSCX.WriteLine(value: $"              <Line LineID=\"2\" EndX=\"{xr - LTascaRet}\" EndY=\"{yr + raio}\" Angle=\"{90}\" />");
				escritaSCX.WriteLine(value: $"              <Line LineID=\"3\" EndX=\"{xr - LTascaRet}\" EndY=\"{yr + HTascaRet - raio}\" Angle=\"{0}\" />");
				escritaSCX.WriteLine(value: $"              <Line LineID=\"4\" EndX=\"{xr - LTascaRet + raio}\" EndY=\"{yr + HTascaRet}\" Angle=\"{90}\" />");
				escritaSCX.WriteLine(value: $"              <Line LineID=\"5\" EndX=\"{xr - raio}\" EndY=\"{yr + HTascaRet}\" Angle=\"{0}\" />");
				escritaSCX.WriteLine(value: $"              <Line LineID=\"6\" EndX=\"{xr}\" EndY=\"{yr + HTascaRet - raio}\" Angle=\"{90}\" />");
				escritaSCX.WriteLine(value: $"              <Line LineID=\"7\" EndX=\"{xr}\" EndY=\"{yr + raio}\" Angle=\"{0}\" />");
				escritaSCX.WriteLine(value: $"              <Line LineID=\"8\" EndX=\"{xr - raio}\" EndY=\"{yr}\" Angle=\"{90}\" />");
				escritaSCX.WriteLine(value: $"            </Lines>");
				escritaSCX.WriteLine(value: $"          </Machining>");
			}

			escritaSCX.Close();
			escritaSCX.Dispose();

			return arquivoSCX;
		}

		public string EscritaTasca_RetInfArc(decimal raio, string arquivoSCX, decimal XTascaRet, decimal YTascaRet, decimal LTascaRet, decimal HTascaRet, decimal ZTascaRet, int NbFace) //Metodo inf_tasca_retArc
		{
			decimal xr = (XTascaRet + LTascaRet / 2);
			decimal yr = (YTascaRet - HTascaRet / 2);

			StreamWriter escritaSCX = new StreamWriter(arquivoSCX, true);
			{
				escritaSCX.WriteLine(value: $"          <Machining Type=\"{3}\" IsGenCode=\"{2}\" Face=\"{NbFace}\" X=\"{xr - raio}\" Y=\"{yr}\" Depth=\"{ZTascaRet}\" Diameter=\"{10}\" ToolOffset=\"Undefined\" Pocket=\"{1}\" Closed=\"{1}\">");
				escritaSCX.WriteLine(value: $"            <MillPreDefinedRectangle Length=\"0\" Width=\"0\" X=\"0\" Y=\"0\" Z=\"0\" Radius=\"0\" CornerBotLeft=\"0\" CornerBotRight=\"0\" CornerTopLeft=\"0\" CornerTopRight=\"0\" />");
				escritaSCX.WriteLine(value: $"            <Lines>");
				escritaSCX.WriteLine(value: $"              <Line LineID=\"0\" EndX=\"{xr - raio}\" EndY=\"{yr}\" Angle=\"{0}\" />");
				escritaSCX.WriteLine(value: $"              <Line LineID=\"1\" EndX=\"{xr - LTascaRet + raio}\" EndY=\"{yr}\" Angle=\"{0}\" />");
				escritaSCX.WriteLine(value: $"              <Line LineID=\"2\" EndX=\"{xr - LTascaRet}\" EndY=\"{yr + raio}\" Angle=\"{90}\" />");
				escritaSCX.WriteLine(value: $"              <Line LineID=\"3\" EndX=\"{xr - LTascaRet}\" EndY=\"{yr + HTascaRet - raio}\" Angle=\"{0}\" />");
				escritaSCX.WriteLine(value: $"              <Line LineID=\"4\" EndX=\"{xr - LTascaRet + raio}\" EndY=\"{yr + HTascaRet}\" Angle=\"{90}\" />");
				escritaSCX.WriteLine(value: $"              <Line LineID=\"5\" EndX=\"{xr - raio}\" EndY=\"{yr + HTascaRet}\" Angle=\"{0}\" />");
				escritaSCX.WriteLine(value: $"              <Line LineID=\"6\" EndX=\"{xr}\" EndY=\"{yr + HTascaRet - raio}\" Angle=\"{90}\" />");
				escritaSCX.WriteLine(value: $"              <Line LineID=\"7\" EndX=\"{xr}\" EndY=\"{yr + raio}\" Angle=\"{0}\" />");
				escritaSCX.WriteLine(value: $"              <Line LineID=\"8\" EndX=\"{xr - raio}\" EndY=\"{yr}\" Angle=\"{90}\" />");
				escritaSCX.WriteLine(value: $"            </Lines>");
				escritaSCX.WriteLine(value: $"          </Machining>");
			}

			escritaSCX.Close();
			escritaSCX.Dispose();

			return arquivoSCX;
		}

		public string EscritaScassoRSupArc(decimal raio, string arquivoSCX, decimal ValorDx, decimal XTascaRet, decimal YTascaRet, decimal LTascaRet, decimal HTascaRet, decimal ZTascaRet, int NbFace, decimal diametro) //Metodo sup_scasso_retArc
		{
			decimal xr = ValorDx - (XTascaRet - LTascaRet / 2);
			decimal yr = YTascaRet - HTascaRet / 2;

			StreamWriter escritaSCX = new StreamWriter(arquivoSCX, true);
			{
				escritaSCX.WriteLine(value: $"          <Machining Type=\"{3}\" IsGenCode=\"{2}\" Face=\"{NbFace}\" X=\"{xr - raio}\" Y=\"{yr}\" Depth=\"{ZTascaRet}\" Diameter=\"{diametro}\" ToolOffset=\"Undefined\" Pocket=\"{1}\" Closed=\"{1}\">");
				escritaSCX.WriteLine(value: $"            <MillPreDefinedRectangle Length=\"0\" Width=\"0\" X=\"0\" Y=\"0\" Z=\"0\" Radius=\"0\" CornerBotLeft=\"0\" CornerBotRight=\"0\" CornerTopLeft=\"0\" CornerTopRight=\"0\" />");
				escritaSCX.WriteLine(value: $"            <Lines>");
				escritaSCX.WriteLine(value: $"              <Line LineID=\"0\" EndX=\"{xr - raio}\" EndY=\"{yr}\" Angle=\"{0}\" />");
				escritaSCX.WriteLine(value: $"              <Line LineID=\"1\" EndX=\"{xr - LTascaRet + raio}\" EndY=\"{yr}\" Angle=\"{0}\" />");
				escritaSCX.WriteLine(value: $"              <Line LineID=\"2\" EndX=\"{xr - LTascaRet}\" EndY=\"{yr + raio}\" Angle=\"{90}\" />");
				escritaSCX.WriteLine(value: $"              <Line LineID=\"3\" EndX=\"{xr - LTascaRet}\" EndY=\"{yr + HTascaRet - raio}\" Angle=\"{0}\" />");
				escritaSCX.WriteLine(value: $"              <Line LineID=\"4\" EndX=\"{xr - LTascaRet + raio}\" EndY=\"{yr + HTascaRet}\" Angle=\"{90}\" />");
				escritaSCX.WriteLine(value: $"              <Line LineID=\"5\" EndX=\"{xr - raio}\" EndY=\"{yr + HTascaRet}\" Angle=\"{0}\" />");
				escritaSCX.WriteLine(value: $"              <Line LineID=\"6\" EndX=\"{xr}\" EndY=\"{yr + HTascaRet - raio}\" Angle=\"{90}\" />");
				escritaSCX.WriteLine(value: $"              <Line LineID=\"7\" EndX=\"{xr}\" EndY=\"{yr + raio}\" Angle=\"{0}\" />");
				escritaSCX.WriteLine(value: $"              <Line LineID=\"8\" EndX=\"{xr - raio}\" EndY=\"{yr}\" Angle=\"{90}\" />");
				escritaSCX.WriteLine(value: $"            </Lines>");
				escritaSCX.WriteLine(value: $"          </Machining>");
			}

			escritaSCX.Close();
			escritaSCX.Dispose();

			return arquivoSCX;
		}

		public string EscritaScassoRInfArc(decimal raio, string arquivoSCX, decimal XTascaRet, decimal YTascaRet, decimal LTascaRet, decimal HTascaRet, decimal ZTascaRet, int NbFace, decimal diametro) //Metodo inf_scasso_retArc
		{
			decimal xr = (XTascaRet + LTascaRet / 2);
			decimal yr = (YTascaRet - HTascaRet / 2);

			StreamWriter escritaSCX = new StreamWriter(arquivoSCX, true);
			{
				escritaSCX.WriteLine(value: $"          <Machining Type=\"{3}\" IsGenCode=\"{2}\" Face=\"{NbFace}\" X=\"{xr - raio}\" Y=\"{yr}\" Depth=\"{ZTascaRet}\" Diameter=\"{diametro}\" ToolOffset=\"Undefined\" Pocket=\"{1}\" Closed=\"{1}\">");
				escritaSCX.WriteLine(value: $"            <MillPreDefinedRectangle Length=\"0\" Width=\"0\" X=\"0\" Y=\"0\" Z=\"0\" Radius=\"0\" CornerBotLeft=\"0\" CornerBotRight=\"0\" CornerTopLeft=\"0\" CornerTopRight=\"0\" />");
				escritaSCX.WriteLine(value: $"            <Lines>");
				escritaSCX.WriteLine(value: $"              <Line LineID=\"0\" EndX=\"{xr - raio}\" EndY=\"{yr}\" Angle=\"{0}\" />");
				escritaSCX.WriteLine(value: $"              <Line LineID=\"1\" EndX=\"{xr - LTascaRet + raio}\" EndY=\"{yr}\" Angle=\"{0}\" />");
				escritaSCX.WriteLine(value: $"              <Line LineID=\"2\" EndX=\"{xr - LTascaRet}\" EndY=\"{yr + raio}\" Angle=\"{90}\" />");
				escritaSCX.WriteLine(value: $"              <Line LineID=\"3\" EndX=\"{xr - LTascaRet}\" EndY=\"{yr + HTascaRet - raio}\" Angle=\"{0}\" />");
				escritaSCX.WriteLine(value: $"              <Line LineID=\"4\" EndX=\"{xr - LTascaRet + raio}\" EndY=\"{yr + HTascaRet}\" Angle=\"{90}\" />");
				escritaSCX.WriteLine(value: $"              <Line LineID=\"5\" EndX=\"{xr - raio}\" EndY=\"{yr + HTascaRet}\" Angle=\"{0}\" />");
				escritaSCX.WriteLine(value: $"              <Line LineID=\"6\" EndX=\"{xr}\" EndY=\"{yr + HTascaRet - raio}\" Angle=\"{90}\" />");
				escritaSCX.WriteLine(value: $"              <Line LineID=\"7\" EndX=\"{xr}\" EndY=\"{yr + raio}\" Angle=\"{0}\" />");
				escritaSCX.WriteLine(value: $"              <Line LineID=\"8\" EndX=\"{xr - raio}\" EndY=\"{yr}\" Angle=\"{90}\" />");
				escritaSCX.WriteLine(value: $"            </Lines>");
				escritaSCX.WriteLine(value: $"          </Machining>");
			}

			escritaSCX.Close();
			escritaSCX.Dispose();

			return arquivoSCX;
		}
		
		public string EscritaTasca_RetSup(string arquivoSCX, decimal ValorDx, decimal XTascaRet, decimal YTascaRet, decimal LTascaRet, decimal HTascaRet, decimal ZTascaRet, int NbFace) //Metodo sup_tasca_ret
		{
			decimal xr = ValorDx - (XTascaRet - LTascaRet / 2);
			decimal yr = YTascaRet - HTascaRet / 2;

			StreamWriter escritaSCX = new StreamWriter(arquivoSCX, true);
			{
				escritaSCX.WriteLine(value: $"          <Machining Type=\"{3}\" IsGenCode=\"{2}\" Face=\"{NbFace}\" X=\"{xr}\" Y=\"{yr}\" Depth=\"{ZTascaRet}\" Diameter=\"{10}\" ToolOffset=\"Undefined\" Pocket=\"{1}\" Closed=\"{1}\">");
				escritaSCX.WriteLine(value: $"            <MillPreDefinedRectangle Length=\"0\" Width=\"0\" X=\"0\" Y=\"0\" Z=\"0\" Radius=\"0\" CornerBotLeft=\"0\" CornerBotRight=\"0\" CornerTopLeft=\"0\" CornerTopRight=\"0\" />");
				escritaSCX.WriteLine(value: $"            <Lines>");
				escritaSCX.WriteLine(value: $"              <Line LineID=\"0\" EndX=\"{xr}\" EndY=\"{yr}\" Angle=\"{0}\" />");
				escritaSCX.WriteLine(value: $"              <Line LineID=\"1\" EndX=\"{xr - LTascaRet}\" EndY=\"{yr}\" Angle=\"{0}\" />");
				escritaSCX.WriteLine(value: $"              <Line LineID=\"2\" EndX=\"{xr - LTascaRet}\" EndY=\"{yr + HTascaRet}\" Angle=\"{0}\" />");
				escritaSCX.WriteLine(value: $"              <Line LineID=\"3\" EndX=\"{xr}\" EndY=\"{yr + HTascaRet}\" Angle=\"{0}\" />");
				escritaSCX.WriteLine(value: $"            </Lines>");
				escritaSCX.WriteLine(value: $"          </Machining>");
			}

			escritaSCX.Close();
			escritaSCX.Dispose();

			return arquivoSCX;
		}

		public string EscritaTasca_RetInf(string arquivoSCX, decimal XTascaRet, decimal YTascaRet, decimal LTascaRet, decimal HTascaRet, decimal ZTascaRet, int NbFace) //Metodo inf_scasso_ret
		{
			decimal xr = (XTascaRet + HTascaRet / 2);
			decimal yr = (YTascaRet - HTascaRet / 2);

			StreamWriter escritaSCX = new StreamWriter(arquivoSCX, true);
			{
				escritaSCX.WriteLine(value: $"          <Machining Type=\"{3}\" IsGenCode=\"{2}\" Face=\"{NbFace}\" X=\"{xr}\" Y=\"{yr}\" Depth=\"{ZTascaRet}\" Diameter=\"{10}\" ToolOffset=\"Undefined\" Pocket=\"{1}\" Closed=\"{1}\">");
				escritaSCX.WriteLine(value: $"            <MillPreDefinedRectangle Length=\"0\" Width=\"0\" X=\"0\" Y=\"0\" Z=\"0\" Radius=\"0\" CornerBotLeft=\"0\" CornerBotRight=\"0\" CornerTopLeft=\"0\" CornerTopRight=\"0\" />");
				escritaSCX.WriteLine(value: $"            <Lines>");
				escritaSCX.WriteLine(value: $"              <Line LineID=\"0\" EndX=\"{xr}\" EndY=\"{yr}\" Angle=\"{0}\" />");
				escritaSCX.WriteLine(value: $"              <Line LineID=\"1\" EndX=\"{xr - LTascaRet}\" EndY=\"{yr}\" Angle=\"{0}\" />");
				escritaSCX.WriteLine(value: $"              <Line LineID=\"2\" EndX=\"{xr - LTascaRet}\" EndY=\"{yr + HTascaRet}\" Angle=\"{0}\" />");
				escritaSCX.WriteLine(value: $"              <Line LineID=\"3\" EndX=\"{xr}\" EndY=\"{yr + HTascaRet}\" Angle=\"{0}\" />");
				escritaSCX.WriteLine(value: $"            </Lines>");
				escritaSCX.WriteLine(value: $"          </Machining>");
			}

			escritaSCX.Close();
			escritaSCX.Dispose();

			return arquivoSCX;
		}

		public string EscritaScassoRSup(string arquivoSCX, decimal ValorDx, decimal XTascaRet, decimal YTascaRet, decimal LTascaRet, decimal HTascaRet, decimal ZTascaRet, int NbFace, decimal diametro) //Metodo sup_scasso_ret
		{
			decimal xr = ValorDx - (XTascaRet - LTascaRet / 2);
			decimal yr = YTascaRet - HTascaRet / 2;

			StreamWriter escritaSCX = new StreamWriter(arquivoSCX, true);
			{
				escritaSCX.WriteLine(value: $"          <Machining Type=\"{3}\" IsGenCode=\"{2}\" Face=\"{NbFace}\" X=\"{xr}\" Y=\"{yr}\" Depth=\"{ZTascaRet}\" Diameter=\"{diametro}\" ToolOffset=\"Undefined\" Pocket=\"{1}\" Closed=\"{1}\">");
				escritaSCX.WriteLine(value: $"            <MillPreDefinedRectangle Length=\"0\" Width=\"0\" X=\"0\" Y=\"0\" Z=\"0\" Radius=\"0\" CornerBotLeft=\"0\" CornerBotRight=\"0\" CornerTopLeft=\"0\" CornerTopRight=\"0\" />");
				escritaSCX.WriteLine(value: $"            <Lines>");
				escritaSCX.WriteLine(value: $"              <Line LineID=\"0\" EndX=\"{xr}\" EndY=\"{yr}\" Angle=\"{0}\" />");
				escritaSCX.WriteLine(value: $"              <Line LineID=\"1\" EndX=\"{xr - LTascaRet}\" EndY=\"{yr}\" Angle=\"{0}\" />");
				escritaSCX.WriteLine(value: $"              <Line LineID=\"2\" EndX=\"{xr - LTascaRet}\" EndY=\"{yr + HTascaRet}\" Angle=\"{0}\" />");
				escritaSCX.WriteLine(value: $"              <Line LineID=\"3\" EndX=\"{xr}\" EndY=\"{yr + HTascaRet}\" Angle=\"{0}\" />");
				escritaSCX.WriteLine(value: $"            </Lines>");
				escritaSCX.WriteLine(value: $"          </Machining>");
			}

			escritaSCX.Close();
			escritaSCX.Dispose();

			return arquivoSCX;
		}

		public string EscritaScassoRInf(string arquivoSCX, decimal XTascaRet, decimal YTascaRet, decimal LTascaRet, decimal HTascaRet, decimal ZTascaRet, int NbFace, decimal diametro) //Metodo inf_tasca_ret
		{
			decimal xr = (XTascaRet + HTascaRet / 2);
			decimal yr = (YTascaRet - HTascaRet / 2);

			StreamWriter escritaSCX = new StreamWriter(arquivoSCX, true);
			{
				escritaSCX.WriteLine(value: $"          <Machining Type=\"{3}\" IsGenCode=\"{2}\" Face=\"{NbFace}\" X=\"{xr}\" Y=\"{yr}\" Depth=\"{ZTascaRet}\" Diameter=\"{diametro}\" ToolOffset=\"Undefined\" Pocket=\"{1}\" Closed=\"{1}\">");
				escritaSCX.WriteLine(value: $"            <MillPreDefinedRectangle Length=\"0\" Width=\"0\" X=\"0\" Y=\"0\" Z=\"0\" Radius=\"0\" CornerBotLeft=\"0\" CornerBotRight=\"0\" CornerTopLeft=\"0\" CornerTopRight=\"0\" />");
				escritaSCX.WriteLine(value: $"            <Lines>");
				escritaSCX.WriteLine(value: $"              <Line LineID=\"0\" EndX=\"{xr}\" EndY=\"{yr}\" Angle=\"{0}\" />");
				escritaSCX.WriteLine(value: $"              <Line LineID=\"1\" EndX=\"{xr - LTascaRet}\" EndY=\"{yr}\" Angle=\"{0}\" />");
				escritaSCX.WriteLine(value: $"              <Line LineID=\"2\" EndX=\"{xr - LTascaRet}\" EndY=\"{yr + HTascaRet}\" Angle=\"{0}\" />");
				escritaSCX.WriteLine(value: $"              <Line LineID=\"3\" EndX=\"{xr}\" EndY=\"{yr + HTascaRet}\" Angle=\"{0}\" />");
				escritaSCX.WriteLine(value: $"            </Lines>");
				escritaSCX.WriteLine(value: $"          </Machining>");
			}

			escritaSCX.Close();
			escritaSCX.Dispose();

			return arquivoSCX;
		}

		public string EscritaTasca_CircSup(string arquivoSCX, decimal ValorDX, decimal XTascaCirc, decimal YTascaCirc, decimal DTascaCirc, decimal ZTascaCirc, int NbFace) //Metodo tasca_circ
		{
			StreamWriter escritaSCX = new StreamWriter(arquivoSCX, true);
			{
				escritaSCX.WriteLine(value: $"          <Machining Type=\"{3}\" IsGenCode=\"{2}\" Face=\"{NbFace}\" X=\"{ValorDX - XTascaCirc}\" Y=\"{YTascaCirc + DTascaCirc / 2}\" Depth=\"{ZTascaCirc}\" Diameter=\"{DTascaCirc}\" ToolOffset=\"Undefined\" Pocket=\"{1}\" Closed=\"{1}\">");
				escritaSCX.WriteLine(value: $"            <MillPreDefinedRectangle Length=\"0\" Width=\"0\" X=\"0\" Y=\"0\" Z=\"0\" Radius=\"0\" CornerBotLeft=\"0\" CornerBotRight=\"0\" CornerTopLeft=\"0\" CornerTopRight=\"0\" />");
				escritaSCX.WriteLine(value: $"            <Lines>");
				escritaSCX.WriteLine(value: $"              <Line LineID=\"0\" EndX=\"{ValorDX - XTascaCirc}\" EndY=\"{YTascaCirc - DTascaCirc / 2}\" Angle=\"{180}\" />");
				escritaSCX.WriteLine(value: $"              <Line LineID=\"1\" EndX=\"{ValorDX - XTascaCirc}\" EndY=\"{YTascaCirc + DTascaCirc / 2}\" Angle=\"{180}\" />");
				escritaSCX.WriteLine(value: $"            </Lines>");
				escritaSCX.WriteLine(value: $"          </Machining>");
			}

			escritaSCX.Close();
			escritaSCX.Dispose();

			return arquivoSCX;
		}

		public string EscritaTasca_CircInf(string arquivoSCX, decimal ValorDX, decimal ValorDY, decimal XTascaCirc, decimal YTascaCirc, decimal DTascaCirc, decimal ZTascaCirc, int NbFace) //Metodo tasca_circ
		{
			StreamWriter escritaSCX = new StreamWriter(arquivoSCX, true);
			{
				escritaSCX.WriteLine(value: $"          <Machining Type=\"{3}\" IsGenCode=\"{2}\" Face=\"{NbFace}\" X=\"{ValorDX - XTascaCirc}\" Y=\"{ValorDY - (YTascaCirc + DTascaCirc / 2)}\" Depth=\"{ZTascaCirc}\" Diameter=\"{DTascaCirc}\" ToolOffset=\"Undefined\" Pocket=\"{1}\" Closed=\"{1}\">");
				escritaSCX.WriteLine(value: $"            <MillPreDefinedRectangle Length=\"0\" Width=\"0\" X=\"0\" Y=\"0\" Z=\"0\" Radius=\"0\" CornerBotLeft=\"0\" CornerBotRight=\"0\" CornerTopLeft=\"0\" CornerTopRight=\"0\" />");
				escritaSCX.WriteLine(value: $"            <Lines>");
				escritaSCX.WriteLine(value: $"              <Line LineID=\"0\" EndX=\"{ValorDX - XTascaCirc}\" EndY=\"{ValorDY - (YTascaCirc - DTascaCirc / 2)}\" Angle=\"{180}\" />");
				escritaSCX.WriteLine(value: $"              <Line LineID=\"1\" EndX=\"{ValorDX - XTascaCirc}\" EndY=\"{ValorDY - (YTascaCirc + DTascaCirc / 2)}\" Angle=\"{180}\" />");
				escritaSCX.WriteLine(value: $"            </Lines>");
				escritaSCX.WriteLine(value: $"          </Machining>");
			}

			escritaSCX.Close();
			escritaSCX.Dispose();

			return arquivoSCX;
		}

		public string EscritaScassocSup(string arquivoSCX, decimal ValorDX, decimal XScassoc, decimal YScassoc, decimal DScassoc, decimal ZScassoc, int NbFace) //Metodo scasso_circ_sup
		{
			StreamWriter escritaSCX = new StreamWriter(arquivoSCX, true);
			{
				escritaSCX.WriteLine(value: $"          <Machining Type=\"{3}\" IsGenCode=\"{2}\" Face=\"{NbFace}\" X=\"{ValorDX - XScassoc}\" Y=\"{YScassoc + DScassoc / 2}\" Depth=\"{ZScassoc}\" Diameter=\"{DScassoc}\" ToolOffset=\"Undefined\" Pocket=\"{1}\" Closed=\"{1}\">");
				escritaSCX.WriteLine(value: $"            <MillPreDefinedRectangle Length=\"0\" Width=\"0\" X=\"0\" Y=\"0\" Z=\"0\" Radius=\"0\" CornerBotLeft=\"0\" CornerBotRight=\"0\" CornerTopLeft=\"0\" CornerTopRight=\"0\" />");
				escritaSCX.WriteLine(value: $"            <Lines>");
				escritaSCX.WriteLine(value: $"              <Line LineID=\"0\" EndX=\"{ValorDX - XScassoc}\" EndY=\"{YScassoc - DScassoc / 2}\" Angle=\"{180}\" />");
				escritaSCX.WriteLine(value: $"              <Line LineID=\"1\" EndX=\"{ValorDX - XScassoc}\" EndY=\"{YScassoc + DScassoc / 2}\" Angle=\"{180}\" />");
				escritaSCX.WriteLine(value: $"            </Lines>");
				escritaSCX.WriteLine(value: $"          </Machining>");
			}

			escritaSCX.Close();
			escritaSCX.Dispose();

			return arquivoSCX;
		}

		public string EscritaScassocInf(string arquivoSCX, decimal ValorDX , decimal XScassoc, decimal YScassoc, decimal DScassoc, decimal ZScassoc, int NbFace) //Metodo scasso_circ_inf
		{
			StreamWriter escritaSCX = new StreamWriter(arquivoSCX, true);
			{
				escritaSCX.WriteLine(value: $"          <Machining Type=\"{3}\" IsGenCode=\"{2}\" Face=\"{NbFace}\" X=\"{ValorDX - XScassoc}\" Y=\"{(YScassoc + DScassoc / 2)}\" Depth=\"{ZScassoc}\" Diameter=\"{DScassoc}\" ToolOffset=\"Undefined\" Pocket=\"{1}\" Closed=\"{1}\">");
				escritaSCX.WriteLine(value: $"            <MillPreDefinedRectangle Length=\"0\" Width=\"0\" X=\"0\" Y=\"0\" Z=\"0\" Radius=\"0\" CornerBotLeft=\"0\" CornerBotRight=\"0\" CornerTopLeft=\"0\" CornerTopRight=\"0\" />");
				escritaSCX.WriteLine(value: $"            <Lines>");
				escritaSCX.WriteLine(value: $"              <Line LineID=\"0\" EndX=\"{ValorDX - XScassoc}\" EndY=\"{(YScassoc - DScassoc / 2)}\" Angle=\"{180}\" />");
				escritaSCX.WriteLine(value: $"              <Line LineID=\"1\" EndX=\"{ValorDX - XScassoc}\" EndY=\"{(YScassoc + DScassoc / 2)}\" Angle=\"{180}\" />");
				escritaSCX.WriteLine(value: $"            </Lines>");
				escritaSCX.WriteLine(value: $"          </Machining>");
			}

			escritaSCX.Close();
			escritaSCX.Dispose();

			return arquivoSCX;
		}

		public string EscritaChannelX(string arquivoSCX, decimal EspPeca, decimal XChannel, decimal YChannel, decimal ZChannel, decimal sChannel, int nbFace, decimal espTool) //Metodo ChannelX
		{
			StreamWriter escritaSCX = new StreamWriter(arquivoSCX, true);
			{
				escritaSCX.WriteLine(value: $"          <Machining Type=\"{4}\" IsGenCode=\"{2}\" Face=\"{nbFace}\" X=\"{XChannel}\" Y=\"{YChannel}\" Z=\"{EspPeca}\" EndX=\"{sChannel}\" EndY=\"{YChannel}\" EndZ=\"{EspPeca}\" Depth=\"{ZChannel}\" Width=\"{espTool}\" ToolOffset=\"{'中'}\" />"); //Centro: 中 //Esquerdo: 左 //Direito: 右
			}

			escritaSCX.Close();
			escritaSCX.Dispose();

			return arquivoSCX;
		}

		public string EscritaChannelY(string arquivoSCX, decimal EspPeca, decimal XChannel, decimal YChannel, decimal ZChannel, decimal sChannel, int nbFace, decimal espTool) //Metodo ChannelY
		{
			StreamWriter escritaSCX = new StreamWriter(arquivoSCX, true);
			{
				escritaSCX.WriteLine(value: $"          <Machining Type=\"{4}\" IsGenCode=\"{2}\" Face=\"{nbFace}\" X=\"{XChannel}\" Y=\"{YChannel}\" Z=\"{EspPeca}\" EndX=\"{XChannel}\" EndY=\"{sChannel}\" EndZ=\"{EspPeca}\" Depth=\"{ZChannel}\" Width=\"{espTool}\" ToolOffset=\"{'中'}\" />"); //Centro: 中 //Esquerdo: 左 //Direito: 右
			}

			escritaSCX.Close();
			escritaSCX.Dispose();

			return arquivoSCX;
		}

		public string EscritaXL2PX2AR(string arquivoSCX, decimal ValorDX, int dimarrayXL2PXAR2ini, int dimarrayXL2PXAR2fim, int NbFace, decimal XIni, decimal YIni, decimal ZIni, decimal diametrotool, decimal XFim, decimal YFim, decimal valoranguloarco) //Metodo XL2P XAR2
		{
			StreamWriter escritaSCX = new StreamWriter(arquivoSCX, true);
			{
				if (dimarrayXL2PXAR2ini == 0)
				{
					escritaSCX.WriteLine(value: $"          <Machining Type=\"{3}\" IsGenCode=\"{2}\" Face=\"{NbFace}\" X=\"{ValorDX - XIni}\" Y=\"{YIni}\" Depth=\"{ZIni}\" Diameter=\"{diametrotool}\" ToolOffset=\"Undefined\" Pocket=\"{0}\" Closed=\"{0}\">");
					escritaSCX.WriteLine(value: $"            <MillPreDefinedRectangle Length=\"0\" Width=\"0\" X=\"0\" Y=\"0\" Z=\"0\" Radius=\"0\" CornerBotLeft=\"0\" CornerBotRight=\"0\" CornerTopLeft=\"0\" CornerTopRight=\"0\" />");
					escritaSCX.WriteLine(value: $"            <Lines>");
				}

				escritaSCX.WriteLine(value: $"              <Line LineID=\"{0}\" EndX=\"{ValorDX - XFim}\" EndY=\"{YFim}\" Angle=\"{valoranguloarco}\" />");

				if (dimarrayXL2PXAR2ini == dimarrayXL2PXAR2fim)
				{
					escritaSCX.WriteLine(value: $"            </Lines>");
					escritaSCX.WriteLine(value: $"          </Machining>");
				}
			}

			escritaSCX.Close();
			escritaSCX.Dispose();

			return arquivoSCX;
		}
	}
}
